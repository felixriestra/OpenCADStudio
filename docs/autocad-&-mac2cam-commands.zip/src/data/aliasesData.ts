import { ALL_AUTOCAD_COMMANDS } from './commandsData';
export { ALL_AUTOCAD_COMMANDS } from './commandsData';

export const AUTOCAD_ALIASES = ALL_AUTOCAD_COMMANDS;

export const CATEGORY_COLORS: Record<string, { bg: string; text: string; border: string }> = {
  'Draw': { bg: 'bg-blue-50 text-blue-800 border-blue-200', text: 'text-blue-700', border: 'border-blue-300' },
  'Modify': { bg: 'bg-emerald-50 text-emerald-800 border-emerald-200', text: 'text-emerald-700', border: 'border-emerald-300' },
  'Dimension': { bg: 'bg-amber-50 text-amber-800 border-amber-200', text: 'text-amber-700', border: 'border-amber-300' },
  'Annotation': { bg: 'bg-purple-50 text-purple-800 border-purple-200', text: 'text-purple-700', border: 'border-purple-300' },
  'Layers & Properties': { bg: 'bg-indigo-50 text-indigo-800 border-indigo-200', text: 'text-indigo-700', border: 'border-indigo-300' },
  'View & Navigation': { bg: 'bg-cyan-50 text-cyan-800 border-cyan-200', text: 'text-cyan-700', border: 'border-cyan-300' },
  'Blocks & References': { bg: 'bg-orange-50 text-orange-800 border-orange-200', text: 'text-orange-700', border: 'border-orange-300' },
  'Inquiry & Measure': { bg: 'bg-rose-50 text-rose-800 border-rose-200', text: 'text-rose-700', border: 'border-rose-300' },
  '3D Modeling': { bg: 'bg-teal-50 text-teal-800 border-teal-200', text: 'text-teal-700', border: 'border-teal-300' },
  'System & Utilities': { bg: 'bg-slate-100 text-slate-800 border-slate-300', text: 'text-slate-700', border: 'border-slate-400' },
};
