import { KeyboardShortcut } from '../types';

export const KEYBOARD_SHORTCUTS: KeyboardShortcut[] = [
  // Function keys
  { key: 'F1', name: 'Help', description: 'Displays contextual Help documentation for active command or window.', category: 'Function Keys' },
  { key: 'F2', name: 'Text Window', description: 'Expands the Command Line history log window.', category: 'Function Keys' },
  { key: 'F3', name: 'OSNAP Toggle', description: 'Toggles Running Object Snap (Endpoint, Midpoint, Center, Intersection).', category: 'Function Keys' },
  { key: 'F4', name: '3D OSNAP', description: 'Toggles 3D Object Snap modes for solid faces, edges, and vertices.', category: 'Function Keys' },
  { key: 'F5', name: 'Isoplane', description: 'Cycles between 2D Isometric planes (Top, Left, Right).', category: 'Function Keys' },
  { key: 'F6', name: 'Dynamic UCS', description: 'Toggles automatic alignment of the UCS to planar solid faces.', category: 'Function Keys' },
  { key: 'F7', name: 'Grid Display', description: 'Toggles background drafting grid on or off.', category: 'Function Keys' },
  { key: 'F8', name: 'Ortho Mode', description: 'Constrains cursor movement strictly to 90° horizontal and vertical axes.', category: 'Function Keys' },
  { key: 'F9', name: 'Grid Snap', description: 'Constrains cursor movement to discrete grid intervals.', category: 'Function Keys' },
  { key: 'F10', name: 'Polar Tracking', description: 'Guides cursor along specified incremental angle vectors.', category: 'Function Keys' },
  { key: 'F11', name: 'Object Snap Tracking', description: 'Tracks cursor along alignment paths from existing object snap points.', category: 'Function Keys' },
  { key: 'F12', name: 'Dynamic Input', description: 'Displays command prompts, coordinate inputs, and dimensions near the cursor.', category: 'Function Keys' },

  // Control shortcuts
  { key: 'Ctrl + 0', name: 'Clean Screen', description: 'Hides toolbars, ribbons, and palettes to maximize drawing area canvas.', category: 'Control Shortcuts' },
  { key: 'Ctrl + 1', name: 'Properties Palette', description: 'Opens or closes the object Properties inspector palette.', category: 'Control Shortcuts' },
  { key: 'Ctrl + 2', name: 'DesignCenter', description: 'Opens AutoCAD DesignCenter (browse blocks, styles, layers across files).', category: 'Control Shortcuts' },
  { key: 'Ctrl + 3', name: 'Tool Palettes', description: 'Opens the Tool Palettes window with categorized drafting symbols.', category: 'Control Shortcuts' },
  { key: 'Ctrl + 4', name: 'Sheet Set Manager', description: 'Opens the Sheet Set Manager palette to organize multi-sheet drawings.', category: 'Control Shortcuts' },
  { key: 'Ctrl + 8', name: 'QuickCalc', description: 'Opens the QuickCalc interactive calculation palette.', category: 'Control Shortcuts' },
  { key: 'Ctrl + 9', name: 'Command Line', description: 'Toggles the Command Line prompt bar visibility on or off.', category: 'Control Shortcuts' },
  { key: 'Ctrl + Shift + C', name: 'Copy with Base Point', description: 'Copies selected objects to clipboard with an explicit user base point.', category: 'Control Shortcuts' },
  { key: 'Ctrl + Shift + V', name: 'Paste as Block', description: 'Pastes copied clipboard objects directly as a new anonymous block.', category: 'Control Shortcuts' },
  { key: 'Ctrl + S', name: 'Save', description: 'Saves current drawing (QSAVE).', category: 'Control Shortcuts' },
  { key: 'Ctrl + P', name: 'Plot / Print', description: 'Opens the Plot dialog to publish or print sheets to PDF or plotter.', category: 'Control Shortcuts' },
  { key: 'Ctrl + Z', name: 'Undo', description: 'Reverses the most recent action or command.', category: 'Control Shortcuts' },
  { key: 'Ctrl + Y', name: 'Redo', description: 'Re-applies the most recent undone action.', category: 'Control Shortcuts' },
  { key: 'Ctrl + A', name: 'Select All', description: 'Selects all unlocked objects in current model or paper space.', category: 'Control Shortcuts' },
];
