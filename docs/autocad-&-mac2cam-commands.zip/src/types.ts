export type CommandCategory =
  | 'Draw'
  | 'Modify'
  | 'Dimension'
  | 'Annotation'
  | 'Layers & Properties'
  | 'View & Navigation'
  | 'Blocks & References'
  | 'Inquiry & Measure'
  | '3D Modeling'
  | 'System & Utilities';

export interface AutoCADAlias {
  id: string;
  alias: string;
  hasDefaultAlias: boolean;
  suggestedAlias?: string;
  command: string;
  category: CommandCategory;
  description: string;
  syntax: string;
  tips?: string;
  isSingleKey: boolean;
  frequency: 'Essential' | 'Common' | 'Advanced';
  tags: string[];
}

export interface KeyboardShortcut {
  key: string;
  name: string;
  description: string;
  category: 'Function Keys' | 'Control Shortcuts' | 'Shift / Mouse';
}

export type ViewMode = 'table' | 'sysvars' | 'extended' | 'document' | 'guide' | 'customizer';

export interface FilterState {
  search: string;
  category: CommandCategory | 'All';
  aliasStatus: 'All' | 'Has-Alias' | 'No-Alias';
  keyType: 'All' | 'Single-Key' | '2-Letter' | '3+ Letter' | 'Numbers';
  frequency: 'All' | 'Essential' | 'Common' | 'Advanced';
  sortBy: 'alias' | 'command' | 'category' | 'frequency';
  sortOrder: 'asc' | 'desc';
}
