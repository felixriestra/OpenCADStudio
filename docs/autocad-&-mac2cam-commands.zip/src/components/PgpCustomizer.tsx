import React, { useState } from 'react';
import { AutoCADAlias } from '../types';
import { 
  Settings, 
  Plus, 
  Trash2, 
  Download, 
  Copy, 
  Check, 
  AlertTriangle, 
  FileUp, 
  Terminal, 
  Sparkles, 
  RefreshCw 
} from 'lucide-react';

interface CustomAliasItem {
  id: string;
  alias: string;
  command: string;
  notes?: string;
}

interface PgpCustomizerProps {
  defaultAliases: AutoCADAlias[];
  onImportCustomAliases?: (newAliases: AutoCADAlias[]) => void;
}

export const PgpCustomizer: React.FC<PgpCustomizerProps> = ({ defaultAliases }) => {
  const [customList, setCustomList] = useState<CustomAliasItem[]>([
    { id: '1', alias: 'CC', command: 'COPY', notes: 'Double-tap C for quick duplicate' },
    { id: '2', alias: 'ZA', command: 'ZOOM', notes: 'Quick Zoom All' },
    { id: '3', alias: 'ZE', command: 'ZOOM', notes: 'Quick Zoom Extents' },
    { id: '4', alias: 'LL', command: 'LAYER', notes: 'Faster layer manager access' },
  ]);

  const [inputAlias, setInputAlias] = useState('');
  const [inputCommand, setInputCommand] = useState('');
  const [inputNotes, setInputNotes] = useState('');
  const [copied, setCopied] = useState(false);
  const [pasteText, setPasteText] = useState('');
  const [parseStatus, setParseStatus] = useState<string | null>(null);

  // Check if alias conflicts with default stock alias
  const conflict = inputAlias.trim()
    ? defaultAliases.find(
        (d) => d.hasDefaultAlias && d.alias.toUpperCase() === inputAlias.trim().toUpperCase()
      )
    : undefined;

  // Recommended shortcuts for commands that don't have default aliases
  const unaliasedRecommendations = [
    { alias: 'OK', command: 'OVERKILL', notes: 'Cleanup duplicate & overlapping lines' },
    { alias: 'CHS', command: 'CHSPACE', notes: 'Transfer entities between Model & Paper space' },
    { alias: 'BST', command: 'BURST', notes: 'Explode block preserving text attributes' },
    { alias: 'FLAT', command: 'FLATTEN', notes: 'Convert 3D geometry to 2D elevations' },
    { alias: 'SS', command: 'SELECTSIMILAR', notes: 'Select all matching layer/type objects' },
    { alias: 'RI', command: 'REINIT', notes: 'Reload acad.pgp without restarting AutoCAD' },
  ];

  const handleAddPreset = (preset: { alias: string; command: string; notes: string }) => {
    if (customList.some((c) => c.alias === preset.alias)) return;
    setCustomList([
      ...customList,
      {
        id: Date.now().toString() + Math.random().toString(),
        alias: preset.alias,
        command: preset.command,
        notes: preset.notes,
      },
    ]);
  };

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputAlias.trim() || !inputCommand.trim()) return;

    const newItem: CustomAliasItem = {
      id: Date.now().toString(),
      alias: inputAlias.trim().toUpperCase(),
      command: inputCommand.trim().toUpperCase().replace(/^\*/, ''),
      notes: inputNotes.trim(),
    };

    setCustomList([...customList, newItem]);
    setInputAlias('');
    setInputCommand('');
    setInputNotes('');
  };

  const handleRemove = (id: string) => {
    setCustomList(customList.filter((item) => item.id !== id));
  };

  // Generate acad.pgp output snippet
  const generatedPgpText = `; =================================================================
; USER DEFINED COMMAND ALIASES
; Placed at the end of acad.pgp to override default alias assignments.
; To reload without restarting AutoCAD: type REINIT, check "PGP File", click OK.
; =================================================================
${customList
  .map((item) => {
    const paddedAlias = item.alias.padEnd(8, ' ');
    const note = item.notes ? ` ; ${item.notes}` : '';
    return `${paddedAlias}, *${item.command}${note}`;
  })
  .join('\n')}
`;

  const handleCopyPgp = () => {
    navigator.clipboard.writeText(generatedPgpText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadPgp = () => {
    const blob = new Blob([generatedPgpText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'custom_acad_aliases.pgp';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleParsePaste = () => {
    if (!pasteText.trim()) return;

    const lines = pasteText.split('\n');
    const regex = /^\s*([A-Za-z0-9_-]+)\s*,\s*\*([A-Za-z0-9_-]+)(?:\s*;\s*(.*))?$/;
    const extracted: CustomAliasItem[] = [];

    lines.forEach((line) => {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith(';')) return;
      const match = trimmed.match(regex);
      if (match) {
        extracted.push({
          id: Math.random().toString(36).substring(2, 9),
          alias: match[1].toUpperCase(),
          command: match[2].toUpperCase(),
          notes: match[3] || 'Imported from custom PGP',
        });
      }
    });

    if (extracted.length > 0) {
      setCustomList((prev) => [...prev, ...extracted]);
      setParseStatus(`Successfully parsed and added ${extracted.length} custom aliases!`);
      setPasteText('');
      setTimeout(() => setParseStatus(null), 3500);
    } else {
      setParseStatus('No valid "ALIAS, *COMMAND" lines found in input.');
      setTimeout(() => setParseStatus(null), 3500);
    }
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Intro */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-red-600 mb-2">
          <Settings className="w-4 h-4" />
          <span>acad.pgp Customizer &amp; Exporter</span>
        </div>
        <h2 className="text-2xl font-bold text-slate-900 tracking-tight">
          Create, Test &amp; Export Custom AutoCAD Aliases
        </h2>
        <p className="text-sm text-slate-600 mt-2 leading-relaxed">
          The Autodesk guide recommends appending your custom aliases to the bottom of <code className="text-xs bg-slate-100 px-1 py-0.5 rounded font-mono text-slate-800">acad.pgp</code> under the User Defined section. Use this interactive tool to design custom shortcuts, detect overrides, and export a ready-to-use snippet.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Form & Current Custom List */}
        <div className="lg:col-span-6 space-y-6">
          {/* Add New Custom Alias Form */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
            <h3 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-1.5">
              <Plus className="w-4 h-4 text-red-600" />
              <span>Define New Command Alias</span>
            </h3>

            <form onSubmit={handleAdd} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Alias (e.g. CC, ZA, L1)
                  </label>
                  <input
                    type="text"
                    value={inputAlias}
                    onChange={(e) => setInputAlias(e.target.value)}
                    placeholder="e.g. CC"
                    className="w-full px-3 py-1.5 text-xs font-mono font-bold rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-red-500 uppercase"
                    maxLength={10}
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    AutoCAD Command
                  </label>
                  <input
                    type="text"
                    value={inputCommand}
                    onChange={(e) => setInputCommand(e.target.value)}
                    placeholder="e.g. COPY"
                    className="w-full px-3 py-1.5 text-xs font-mono rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-red-500 uppercase"
                    required
                  />
                </div>
              </div>

              {/* Conflict warning */}
              {conflict && (
                <div className="p-2.5 rounded-lg bg-amber-50 border border-amber-200 flex items-start gap-2 text-xs text-amber-900">
                  <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold">Override notice:</span>{' '}
                    <code className="font-mono font-bold">{conflict.alias}</code> is currently mapped to default{' '}
                    <code className="font-mono font-bold">{conflict.command}</code>. Appending it to the bottom of <code className="font-mono">acad.pgp</code> will override the default in AutoCAD.
                  </div>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Optional Note / Drafting Reason
                </label>
                <input
                  type="text"
                  value={inputNotes}
                  onChange={(e) => setInputNotes(e.target.value)}
                  placeholder="e.g. Left-hand single hand shortcut"
                  className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-red-500"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2 px-4 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs transition-colors flex items-center justify-center gap-1.5 shadow-xs"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Custom Alias</span>
              </button>
            </form>

            {/* Quick-add presets for unaliased AutoCAD commands */}
            <div className="mt-4 pt-3 border-t border-slate-100">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-700 mb-2">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                <span>Quick-Add Shortcuts for Unaliased Commands:</span>
              </div>
              <div className="grid grid-cols-2 gap-1.5">
                {unaliasedRecommendations.map((rec) => {
                  const isAdded = customList.some((c) => c.alias === rec.alias);
                  return (
                    <button
                      key={rec.alias}
                      type="button"
                      disabled={isAdded}
                      onClick={() => handleAddPreset(rec)}
                      className={`text-left p-1.5 rounded border text-xs flex items-center justify-between transition-colors ${
                        isAdded
                          ? 'bg-slate-50 border-slate-200 text-slate-400 cursor-not-allowed'
                          : 'bg-white hover:bg-indigo-50/60 border-slate-200 hover:border-indigo-300 text-slate-800'
                      }`}
                      title={rec.notes}
                    >
                      <span className="font-mono font-bold text-indigo-700">
                        {rec.alias} <span className="text-slate-500 font-normal">→ *{rec.command}</span>
                      </span>
                      {isAdded ? (
                        <Check className="w-3 h-3 text-emerald-600" />
                      ) : (
                        <Plus className="w-3 h-3 text-slate-400" />
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Current Custom Aliases Table */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-slate-900">
                Active Custom Aliases ({customList.length})
              </h3>
              <span className="text-[11px] text-slate-400">Will be bundled into PGP</span>
            </div>

            {customList.length === 0 ? (
              <p className="text-xs text-slate-400 text-center py-6">
                No custom aliases added yet. Use the form above or paste your existing PGP file below.
              </p>
            ) : (
              <div className="divide-y divide-slate-100 max-h-60 overflow-y-auto">
                {customList.map((item) => (
                  <div key={item.id} className="py-2 flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="w-8 h-6 rounded bg-slate-100 text-slate-900 font-mono font-bold text-xs flex items-center justify-center border border-slate-200">
                        {item.alias}
                      </span>
                      <div>
                        <div className="font-mono text-xs font-bold text-slate-800">
                          *{item.command}
                        </div>
                        {item.notes && (
                          <div className="text-[11px] text-slate-400 italic">{item.notes}</div>
                        )}
                      </div>
                    </div>

                    <button
                      onClick={() => handleRemove(item.id)}
                      className="p-1.5 text-slate-400 hover:text-red-600 rounded hover:bg-slate-100 transition-colors"
                      title="Remove custom alias"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Quick Paste Existing PGP file */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-3">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
              <FileUp className="w-4 h-4 text-blue-600" />
              <span>Import Existing acad.pgp Content</span>
            </h3>
            <p className="text-xs text-slate-500">
              Paste lines from your existing <code className="font-mono">acad.pgp</code> to import and manage them:
            </p>
            <textarea
              rows={3}
              value={pasteText}
              onChange={(e) => setPasteText(e.target.value)}
              placeholder="CC, *COPY ; duplicate&#10;ZA, *ZOOM ; zoom all"
              className="w-full p-2.5 font-mono text-xs rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-red-500 bg-slate-50"
            ></textarea>
            {parseStatus && (
              <div className="text-xs font-medium text-emerald-700 bg-emerald-50 p-2 rounded border border-emerald-200">
                {parseStatus}
              </div>
            )}
            <button
              onClick={handleParsePaste}
              className="w-full py-1.5 px-3 rounded-lg border border-slate-200 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold transition-colors"
            >
              Parse and Import Lines
            </button>
          </div>
        </div>

        {/* Right Column: Output Snippet Preview & Actions */}
        <div className="lg:col-span-6 space-y-6">
          <div className="bg-slate-900 text-slate-100 rounded-xl border border-slate-800 p-5 shadow-xs flex flex-col justify-between h-full">
            <div>
              <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
                <div className="flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-emerald-400" />
                  <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono">
                    acad.pgp Snippet Output
                  </h3>
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={handleCopyPgp}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-mono transition-colors"
                  >
                    {copied ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy All</span>
                      </>
                    )}
                  </button>
                  <button
                    onClick={handleDownloadPgp}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-red-600 hover:bg-red-500 text-white text-xs font-semibold transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download .pgp</span>
                  </button>
                </div>
              </div>

              <pre className="text-xs font-mono text-emerald-400 overflow-x-auto p-3 bg-slate-950 rounded-lg max-h-[380px] overflow-y-auto leading-relaxed border border-slate-800/80">
                <code>{generatedPgpText}</code>
              </pre>
            </div>

            {/* How to deploy in AutoCAD */}
            <div className="mt-5 pt-4 border-t border-slate-800 text-xs text-slate-400 space-y-2">
              <h4 className="font-semibold text-slate-200 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>How to Install into AutoCAD:</span>
              </h4>
              <ol className="list-decimal list-inside space-y-1 text-slate-300 pl-1">
                <li>In AutoCAD, run command: <code className="text-amber-300 font-mono">AI_EDITCUSTFILE</code> &rarr; enter <code className="text-amber-300 font-mono">acad.pgp</code>.</li>
                <li>Scroll to the bottom of the file to the <code className="text-slate-400 font-mono">-- User Defined --</code> section.</li>
                <li>Paste the snippet above and save the file in Notepad.</li>
                <li>Back in AutoCAD, run <code className="text-amber-300 font-mono">REINIT</code>, check <strong>PGP File</strong>, and click OK. Done!</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
