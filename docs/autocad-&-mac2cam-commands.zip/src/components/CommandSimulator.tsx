import React, { useState } from 'react';
import { AutoCADAlias } from '../types';
import { MAC2CAM_CUSTOM_COMMANDS } from '../data/mac2camCommands';
import { AUTOCAD_SYSTEM_VARIABLES } from '../data/sysvarsData';
import { 
  DUPLICATE_ALIAS_COMMANDS, 
  APPLICATION_META_COMMANDS, 
  THREE_D_NON_EXEC_COMMANDS 
} from '../data/extendedCommandsData';
import { Terminal, CornerDownLeft, Sparkles, X, Check } from 'lucide-react';

interface CommandSimulatorProps {
  aliases: AutoCADAlias[];
  onSelectAlias?: (alias: AutoCADAlias) => void;
}

export const CommandSimulator: React.FC<CommandSimulatorProps> = ({ aliases, onSelectAlias }) => {
  const [inputVal, setInputVal] = useState('');
  const [history, setHistory] = useState<
    { text: string; matchedAlias?: AutoCADAlias; status: 'matched' | 'unknown' }[]
  >([
    {
      text: 'AutoCAD Command Line Simulator Active. Type any alias (e.g. L, REC, C, TR, LA) and press Enter or Space:',
      status: 'unknown',
    },
  ]);
  const [isMinimized, setIsMinimized] = useState(false);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      const raw = inputVal.trim().toUpperCase();
      if (!raw) return;

      const found = aliases.find(
        (a) =>
          (a.hasDefaultAlias && a.alias.toUpperCase() === raw) ||
          a.command.toUpperCase() === raw ||
          (a.suggestedAlias && a.suggestedAlias.toUpperCase() === raw)
      );

      if (found) {
        let msg = `Command: ${raw} -> Executing ${found.command} (${found.description})`;
        if (!found.hasDefaultAlias) {
          if (found.suggestedAlias && raw === found.suggestedAlias.toUpperCase()) {
            msg = `Command: ${raw} (Custom Suggested Alias) -> Executing ${found.command} (${found.description})`;
          } else {
            msg = `Command: ${raw} (Full AutoCAD Command) -> Executing ${found.command} (${found.description})`;
          }
        }
        setHistory((prev) => [
          ...prev.slice(-3),
          {
            text: msg,
            matchedAlias: found,
            status: 'matched',
          },
        ]);
        if (onSelectAlias) onSelectAlias(found);
      } else {
        // Strip leading apostrophe if typed as transparent command 'OSMODE
        const cleanRaw = raw.startsWith("'") ? raw.slice(1) : raw;

        // Check if it matches an AutoCAD System Variable
        const sysVarFound = AUTOCAD_SYSTEM_VARIABLES.find(
          (v) => v.name.toUpperCase() === cleanRaw
        );

        if (sysVarFound) {
          const modeTag = raw.startsWith("'") ? 'Transparent SysVar' : 'AutoCAD System Variable';
          const promptMsg = sysVarFound.access === 'Read-Only'
            ? `${sysVarFound.name} = "${sysVarFound.defaultValue}" (read only) [${sysVarFound.group} - ${sysVarFound.description}]`
            : `Enter new value for ${sysVarFound.name} <${sysVarFound.defaultValue}>: [${sysVarFound.group} - ${sysVarFound.description}]`;

          setHistory((prev) => [
            ...prev.slice(-3),
            {
              text: `Command: ${raw} (${modeTag}) -> ${promptMsg}`,
              status: 'matched',
            },
          ]);
        } else {
          // Check if it matches a Mac2CAM custom command
          const mac2camFound = MAC2CAM_CUSTOM_COMMANDS.find(
            (m) => m.command.toUpperCase() === cleanRaw
          );

          if (mac2camFound) {
            setHistory((prev) => [
              ...prev.slice(-3),
              {
                text: `Command: ${raw} (Mac2CAM Custom Token) -> [${mac2camFound.category}] ${mac2camFound.explanation}. (Standard AutoCAD: ${mac2camFound.autocadEquivalent})`,
                status: 'matched',
              },
            ]);
          } else {
            // Check if it matches a Duplicate Alias Registered as Command
            const dupFound = DUPLICATE_ALIAS_COMMANDS.find(
              (d) => d.aliasToken.toUpperCase() === cleanRaw
            );

            if (dupFound) {
              setHistory((prev) => [
                ...prev.slice(-3),
                {
                  text: `Command: ${raw} (Duplicate Alias Registered as Command) -> Executes *${dupFound.targetCommand} [${dupFound.category}]. (${dupFound.reasonForSeparateRegistration})`,
                  status: 'matched',
                },
              ]);
            } else {
              // Check if it matches an Application / Clipboard Meta-Command
              const metaFound = APPLICATION_META_COMMANDS.find(
                (m) => m.token.toUpperCase() === cleanRaw
              );

              if (metaFound) {
                setHistory((prev) => [
                  ...prev.slice(-3),
                  {
                    text: `Command: ${raw} (Application Meta-Command) -> [${metaFound.actionType}] ${metaFound.description}. Mac2CAM: ${metaFound.mac2camBehavior}`,
                    status: 'matched',
                  },
                ]);
              } else {
                // Check if it matches a 3D / Mesh non-executed command
                const threeDFound = THREE_D_NON_EXEC_COMMANDS.find(
                  (t) => t.token.toUpperCase() === cleanRaw
                );

                if (threeDFound) {
                  setHistory((prev) => [
                    ...prev.slice(-3),
                    {
                      text: `Command: ${raw} (3D & Mesh Sub-Command) -> Recognized by Mac2CAM parser but NOT executed in 2D engine. AutoCAD: ${threeDFound.autocadFunction}. Note: ${threeDFound.technicalNote}`,
                      status: 'matched',
                    },
                  ]);
                } else {
                  setHistory((prev) => [
                    ...prev.slice(-3),
                    {
                      text: `Command: ${raw} -> Unknown command, system variable, or alias. Check acad.pgp, System Variables, or Extended Registry.`,
                      status: 'unknown',
                    },
                  ]);
                }
              }
            }
          }
        }
      }
      setInputVal('');
    }
  };

  if (isMinimized) {
    return (
      <div className="fixed bottom-4 right-4 z-40 print:hidden">
        <button
          onClick={() => setIsMinimized(false)}
          className="flex items-center gap-2 px-3.5 py-2 rounded-lg bg-slate-900 text-white text-xs font-mono font-medium shadow-lg border border-slate-700 hover:bg-slate-800 transition-colors"
        >
          <Terminal className="w-4 h-4 text-emerald-400" />
          <span>AutoCAD Command Line Prompt</span>
        </button>
      </div>
    );
  }

  return (
    <div className="fixed bottom-3 left-4 right-4 md:left-auto md:right-8 md:w-[620px] z-40 bg-slate-950/95 backdrop-blur-md rounded-xl border border-slate-800 shadow-2xl overflow-hidden print:hidden text-slate-100 font-mono text-xs">
      {/* Top mini header */}
      <div className="bg-slate-900/90 px-3 py-1.5 flex items-center justify-between border-b border-slate-800 select-none">
        <div className="flex items-center gap-2">
          <Terminal className="w-3.5 h-3.5 text-emerald-400" />
          <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider">
            AutoCAD Command Line (Press Space or Enter to run)
          </span>
        </div>
        <button
          onClick={() => setIsMinimized(true)}
          className="text-slate-400 hover:text-white p-0.5 rounded"
          title="Minimize prompt"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* History lines */}
      <div className="p-2.5 max-h-20 overflow-y-auto space-y-1 text-[11px]">
        {history.map((h, idx) => (
          <div
            key={idx}
            className={`flex items-start gap-1.5 ${
              h.status === 'matched' ? 'text-emerald-400 font-semibold' : 'text-slate-400'
            }`}
          >
            <span className="text-slate-600 select-none">&gt;</span>
            <span className="leading-snug">{h.text}</span>
          </div>
        ))}
      </div>

      {/* Command prompt input */}
      <div className="px-3 py-2 bg-slate-900/60 border-t border-slate-800/80 flex items-center gap-2">
        <span className="text-emerald-400 font-bold select-none text-xs">Type a command:</span>
        <input
          id="autocad-cmdline-input"
          type="text"
          value={inputVal}
          onChange={(e) => setInputVal(e.target.value.toUpperCase())}
          onKeyDown={handleKeyDown}
          placeholder="e.g. L, C, REC, TR, CO, LA..."
          className="flex-1 bg-transparent border-none text-white font-mono text-xs focus:outline-none placeholder:text-slate-600"
          autoComplete="off"
          spellCheck={false}
        />
        <div className="flex items-center gap-1 text-[10px] text-slate-500 bg-slate-800/80 px-1.5 py-0.5 rounded border border-slate-700">
          <CornerDownLeft className="w-3 h-3 text-slate-400" />
          <span>Enter / Space</span>
        </div>
      </div>
    </div>
  );
};
