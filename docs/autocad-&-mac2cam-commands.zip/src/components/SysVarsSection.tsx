import React, { useState, useMemo } from 'react';
import { AUTOCAD_SYSTEM_VARIABLES, AutoCADSysVar } from '../data/sysvarsData';
import { 
  Sliders, 
  Search, 
  Copy, 
  Check, 
  HelpCircle, 
  ChevronRight, 
  ChevronDown, 
  Filter, 
  Database,
  Terminal,
  Layers,
  Sparkles,
  Info,
  Maximize2
} from 'lucide-react';

interface SysVarsSectionProps {
  isStandAlonePage?: boolean;
}

export const SysVarsSection: React.FC<SysVarsSectionProps> = ({ isStandAlonePage = false }) => {
  const [search, setSearch] = useState('');
  const [selectedGroup, setSelectedGroup] = useState<string>('All');
  const [selectedAccess, setSelectedAccess] = useState<'All' | 'Read/Write' | 'Read-Only'>('All');
  const [copiedName, setCopiedName] = useState<string | null>(null);
  const [selectedVar, setSelectedVar] = useState<AutoCADSysVar | null>(null);
  const [isExpanded, setIsExpanded] = useState(true);

  const groups = [
    'All',
    'Snaps & Cursor',
    'Scale & Display',
    'Units & Dimensioning',
    'Selection & Grips',
    'Frames & Viewports',
    '3D & Shading',
    'File & System',
  ];

  const handleCopy = (text: string, id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(text);
    setCopiedName(id);
    setTimeout(() => setCopiedName(null), 1800);
  };

  const filteredVars = useMemo(() => {
    const q = search.toLowerCase().trim();
    return AUTOCAD_SYSTEM_VARIABLES.filter((v) => {
      if (selectedGroup !== 'All' && v.group !== selectedGroup) return false;
      if (selectedAccess !== 'All' && v.access !== selectedAccess) return false;
      if (q) {
        const matchName = v.name.toLowerCase().includes(q);
        const matchDesc = v.description.toLowerCase().includes(q);
        const matchTips = v.usageTips.toLowerCase().includes(q);
        const matchVal = v.defaultValue.toLowerCase().includes(q);
        if (!matchName && !matchDesc && !matchTips && !matchVal) return false;
      }
      return true;
    });
  }, [search, selectedGroup, selectedAccess]);

  const groupBadgeColor = (group: AutoCADSysVar['group']) => {
    switch (group) {
      case 'Snaps & Cursor':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'Scale & Display':
        return 'bg-cyan-50 text-cyan-700 border-cyan-200';
      case 'Units & Dimensioning':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'Selection & Grips':
        return 'bg-purple-50 text-purple-700 border-purple-200';
      case 'Frames & Viewports':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case '3D & Shading':
        return 'bg-teal-50 text-teal-700 border-teal-200';
      case 'File & System':
        return 'bg-rose-50 text-rose-700 border-rose-200';
      default:
        return 'bg-slate-50 text-slate-700 border-slate-200';
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-xs border border-slate-200 overflow-hidden" id="autocad-sysvars-section">
      {/* Header Banner */}
      <div 
        onClick={() => !isStandAlonePage && setIsExpanded(!isExpanded)}
        className={`p-5 bg-gradient-to-r from-slate-900 via-slate-800 to-sky-950 text-white select-none flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
          !isStandAlonePage ? 'cursor-pointer' : ''
        }`}
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-sky-500/20 border border-sky-400/30 flex items-center justify-center text-sky-400 shadow-inner">
            <Sliders className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-bold text-white tracking-tight">
                AutoCAD System Variables Registry
              </h2>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-sky-500 text-white uppercase tracking-wider">
                {AUTOCAD_SYSTEM_VARIABLES.length} Core SysVars
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-0.5">
              Variables fully recognized directly at the AutoCAD command prompt (type directly or invoke transparently via <code className="text-sky-300 font-mono">'VARNAME</code>)
            </p>
          </div>
        </div>

        {!isStandAlonePage && (
          <div className="flex items-center gap-2 text-xs font-semibold text-sky-300">
            <span>{isExpanded ? 'Collapse Section' : 'Expand Section'}</span>
            {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
          </div>
        )}
      </div>

      {(isExpanded || isStandAlonePage) && (
        <div className="p-5 space-y-4">
          {/* Helpful Information Notice */}
          <div className="bg-sky-50/70 border border-sky-200 rounded-lg p-3.5 text-xs text-sky-950 leading-relaxed flex items-start gap-2.5">
            <Info className="w-4 h-4 text-sky-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold text-sky-900">Recognized at the Command Line: </span>
              In standard AutoCAD, typing any of these system variables into the command bar displays its current value in angle brackets (e.g. <code className="px-1 py-0.5 bg-sky-100 text-sky-900 rounded font-mono font-bold">OSMODE &lt;4133&gt;</code>) and prompts for a new value. You can also type them inside active commands by prefixing an apostrophe (e.g. <code className="px-1 py-0.5 bg-sky-100 text-sky-900 rounded font-mono font-bold">'OSMODE</code>).
            </div>
          </div>

          {/* Search and Filters */}
          <div className="flex flex-col md:flex-row gap-3 items-center justify-between">
            <div className="relative w-full md:w-80">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search variables (e.g. OSMODE, LTSCALE, FILEDIA)..."
                className="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-sky-500 bg-slate-50/50 hover:bg-white"
              />
            </div>

            <div className="flex flex-wrap items-center gap-1.5 w-full md:w-auto">
              <div className="flex items-center rounded-lg border border-slate-200 p-0.5 bg-slate-100 text-xs">
                {(['All', 'Read/Write', 'Read-Only'] as const).map((acc) => (
                  <button
                    key={acc}
                    onClick={() => setSelectedAccess(acc)}
                    className={`py-1 px-2.5 rounded-md font-medium text-center transition-all ${
                      selectedAccess === acc
                        ? 'bg-white text-slate-900 shadow-2xs font-semibold'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {acc}
                  </button>
                ))}
              </div>

              <select
                value={selectedGroup}
                onChange={(e) => setSelectedGroup(e.target.value)}
                className="py-1.5 px-3 rounded-lg border border-slate-200 text-xs font-medium text-slate-700 bg-white focus:outline-none focus:ring-2 focus:ring-sky-500"
              >
                {groups.map((g) => (
                  <option key={g} value={g}>
                    {g === 'All' ? 'All Functional Groups' : g}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Group pills quick switch */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
            {groups.map((g) => {
              const count = g === 'All'
                ? AUTOCAD_SYSTEM_VARIABLES.length
                : AUTOCAD_SYSTEM_VARIABLES.filter((v) => v.group === g).length;
              return (
                <button
                  key={g}
                  onClick={() => setSelectedGroup(g)}
                  className={`px-2.5 py-1 rounded-full text-xs font-medium whitespace-nowrap transition-colors flex items-center gap-1 ${
                    selectedGroup === g
                      ? 'bg-sky-600 text-white shadow-2xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  <span>{g}</span>
                  <span className={`text-[10px] px-1 rounded-full ${selectedGroup === g ? 'bg-sky-800 text-sky-100' : 'bg-slate-200 text-slate-600'}`}>
                    {count}
                  </span>
                </button>
              );
            })}
          </div>

          {/* SysVars Table */}
          <div className="border border-slate-200 rounded-lg overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                    <th className="py-2.5 px-3 w-44">Variable Name</th>
                    <th className="py-2.5 px-3 w-40">Group</th>
                    <th className="py-2.5 px-3 w-28">Default</th>
                    <th className="py-2.5 px-3 w-24">Type / Access</th>
                    <th className="py-2.5 px-3">Description &amp; Drafting Impact</th>
                    <th className="py-2.5 px-3 text-right w-16">Copy</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredVars.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-slate-400">
                        No system variables found matching your search criteria.
                      </td>
                    </tr>
                  ) : (
                    filteredVars.map((v) => (
                      <tr
                        key={v.name}
                        onClick={() => setSelectedVar(v)}
                        className="hover:bg-sky-50/40 cursor-pointer transition-colors group"
                      >
                        <td className="py-2.5 px-3 font-mono font-bold text-sky-950">
                          <span className="px-1.5 py-0.5 rounded bg-sky-50 border border-sky-200 text-sky-950 font-black text-xs">
                            {v.name}
                          </span>
                        </td>

                        <td className="py-2.5 px-3">
                          <span className={`inline-block px-2 py-0.5 rounded text-[11px] font-medium border ${groupBadgeColor(v.group)}`}>
                            {v.group}
                          </span>
                        </td>

                        <td className="py-2.5 px-3 font-mono text-slate-700 text-[11px]">
                          <code className="bg-slate-100 px-1.5 py-0.5 rounded border border-slate-200">
                            {v.defaultValue}
                          </code>
                        </td>

                        <td className="py-2.5 px-3 text-[11px]">
                          <div className="font-medium text-slate-700">{v.type}</div>
                          <div className={`text-[10px] font-semibold ${v.access === 'Read-Only' ? 'text-amber-600' : 'text-slate-400'}`}>
                            {v.access}
                          </div>
                        </td>

                        <td className="py-2.5 px-3 text-slate-700 leading-relaxed">
                          <div>{v.description}</div>
                          {v.usageTips && (
                            <div className="text-[11px] text-sky-800/80 mt-0.5 flex items-center gap-1 font-medium">
                              <span>Tip: {v.usageTips}</span>
                            </div>
                          )}
                        </td>

                        <td className="py-2.5 px-3 text-right">
                          <button
                            onClick={(e) => handleCopy(v.name, v.name, e)}
                            className="p-1 rounded hover:bg-slate-200 text-slate-400 hover:text-slate-700 transition-colors"
                            title={`Copy variable name '${v.name}'`}
                          >
                            {copiedName === v.name ? (
                              <Check className="w-3.5 h-3.5 text-emerald-600" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between text-[11px] text-slate-500 pt-1">
            <span>
              Showing {filteredVars.length} of {AUTOCAD_SYSTEM_VARIABLES.length} standard AutoCAD system variables.
            </span>
            <span>
              All variables accept command-line entry and transparent execution (<code className="font-mono text-slate-700">'VAR</code>).
            </span>
          </div>
        </div>
      )}

      {/* Modal Detail View */}
      {selectedVar && (
        <div
          className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-50 flex items-center justify-center p-4"
          onClick={() => setSelectedVar(null)}
        >
          <div
            className="bg-white rounded-xl shadow-xl border border-slate-200 max-w-md w-full overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="bg-slate-900 text-white p-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded bg-sky-600 font-mono font-black text-sm">
                  {selectedVar.name}
                </span>
                <span className="text-xs text-slate-300">AutoCAD System Variable</span>
              </div>
              <button
                onClick={() => setSelectedVar(null)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3 bg-slate-50 p-3 rounded-lg border border-slate-200">
                <div>
                  <span className="text-slate-400 uppercase font-semibold text-[10px] block">Group</span>
                  <span className="font-medium text-slate-800">{selectedVar.group}</span>
                </div>
                <div>
                  <span className="text-slate-400 uppercase font-semibold text-[10px] block">Default Value</span>
                  <code className="font-mono font-bold text-sky-900">{selectedVar.defaultValue}</code>
                </div>
                <div>
                  <span className="text-slate-400 uppercase font-semibold text-[10px] block">Data Type</span>
                  <span className="font-medium text-slate-800">{selectedVar.type}</span>
                </div>
                <div>
                  <span className="text-slate-400 uppercase font-semibold text-[10px] block">Saved In</span>
                  <span className="font-medium text-slate-800">{selectedVar.savedIn}</span>
                </div>
              </div>

              <div>
                <span className="text-slate-400 uppercase font-semibold text-[10px] block mb-1">
                  Description
                </span>
                <p className="text-slate-800 text-sm leading-relaxed">{selectedVar.description}</p>
              </div>

              <div>
                <span className="text-slate-400 uppercase font-semibold text-[10px] block mb-1">
                  Drafting Tip &amp; Practical Value
                </span>
                <div className="bg-sky-50 border border-sky-200 rounded p-2.5 text-sky-950 leading-relaxed">
                  {selectedVar.usageTips}
                </div>
              </div>

              <div>
                <span className="text-slate-400 uppercase font-semibold text-[10px] block mb-1">
                  How to use at Command Line
                </span>
                <div className="bg-slate-900 text-emerald-400 p-2.5 rounded font-mono text-[11px] space-y-1">
                  <div>Command: {selectedVar.name}</div>
                  <div>Enter new value for {selectedVar.name} &lt;{selectedVar.defaultValue}&gt;:</div>
                </div>
              </div>
            </div>

            <div className="bg-slate-50 border-t border-slate-100 px-5 py-3 flex justify-between items-center">
              <span className="text-[11px] text-slate-400">Standard out-of-the-box AutoCAD variable</span>
              <button
                onClick={() => setSelectedVar(null)}
                className="px-3 py-1.5 rounded-md bg-slate-200 hover:bg-slate-300 font-medium text-slate-800 text-xs"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
