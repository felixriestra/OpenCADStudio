import React from 'react';
import { ViewMode } from '../types';
import { Table, FileText, BookOpen, Settings, Printer, Download, Sparkles, Sliders, Layers } from 'lucide-react';

interface HeaderProps {
  currentView: ViewMode;
  onViewChange: (view: ViewMode) => void;
  onPrint: () => void;
  onExportCSV: () => void;
  onExportMarkdown: () => void;
  totalAliasesCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  currentView,
  onViewChange,
  onPrint,
  onExportCSV,
  onExportMarkdown,
  totalAliasesCount,
}) => {
  return (
    <header className="bg-slate-900 text-white border-b border-slate-800 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top bar with title and quick actions */}
        <div className="py-4 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-red-600 flex items-center justify-center font-black tracking-tighter text-xl shadow-inner text-white">
              A
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
                  AutoCAD &amp; Mac2CAM Commands
                </h1>
                <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-red-900/60 text-red-200 border border-red-700/50">
                  acad.pgp &amp; Mac2CAM
                </span>
                <span className="text-xs bg-slate-800 text-slate-300 px-2 py-0.5 rounded border border-slate-700 font-mono">
                  531 Registered Tokens
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
                Comprehensive reference covering Core Drafting Commands (206), Custom Mac2CAM Tools (52), System Variables (132), Duplicate Registered Aliases (74), Application &amp; Clipboard Meta-Commands (39), and 3D/Mesh Sub-Commands (28).
              </p>
            </div>
          </div>

          {/* Quick action buttons */}
          <div className="flex items-center gap-2 self-start md:self-auto flex-wrap">
            <button
              id="export-csv-btn"
              onClick={onExportCSV}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors shadow-sm"
              title="Export as CSV for Excel or Google Sheets"
            >
              <Download className="w-3.5 h-3.5" />
              <span>CSV</span>
            </button>
            <button
              id="export-md-btn"
              onClick={onExportMarkdown}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors shadow-sm"
              title="Export as Markdown Table"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Markdown</span>
            </button>
            <button
              id="print-doc-btn"
              onClick={onPrint}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium bg-red-600 hover:bg-red-500 text-white transition-colors shadow-sm"
              title="Print or Save as PDF Desk Reference"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / PDF</span>
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-t border-slate-800/80 -mb-px overflow-x-auto no-scrollbar space-x-1 sm:space-x-4 pt-1">
          <button
            id="tab-table"
            onClick={() => onViewChange('table')}
            className={`flex items-center gap-2 py-3 px-3 border-b-2 font-medium text-xs sm:text-sm whitespace-nowrap transition-colors ${
              currentView === 'table'
                ? 'border-red-500 text-red-400 font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-600'
            }`}
          >
            <Table className="w-4 h-4" />
            <span>Interactive Table</span>
          </button>

          <button
            id="tab-sysvars"
            onClick={() => onViewChange('sysvars')}
            className={`flex items-center gap-2 py-3 px-3 border-b-2 font-medium text-xs sm:text-sm whitespace-nowrap transition-colors ${
              currentView === 'sysvars'
                ? 'border-red-500 text-red-400 font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-600'
            }`}
          >
            <Sliders className="w-4 h-4" />
            <span>System Variables</span>
          </button>

          <button
            id="tab-extended"
            onClick={() => onViewChange('extended')}
            className={`flex items-center gap-2 py-3 px-3 border-b-2 font-medium text-xs sm:text-sm whitespace-nowrap transition-colors ${
              currentView === 'extended'
                ? 'border-red-500 text-red-400 font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-600'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>Extended Registry (531)</span>
          </button>

          <button
            id="tab-document"
            onClick={() => onViewChange('document')}
            className={`flex items-center gap-2 py-3 px-3 border-b-2 font-medium text-xs sm:text-sm whitespace-nowrap transition-colors ${
              currentView === 'document'
                ? 'border-red-500 text-red-400 font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-600'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Structured Document</span>
          </button>

          <button
            id="tab-guide"
            onClick={() => onViewChange('guide')}
            className={`flex items-center gap-2 py-3 px-3 border-b-2 font-medium text-xs sm:text-sm whitespace-nowrap transition-colors ${
              currentView === 'guide'
                ? 'border-red-500 text-red-400 font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-600'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>How to Create &amp; Manage Aliases</span>
          </button>

          <button
            id="tab-customizer"
            onClick={() => onViewChange('customizer')}
            className={`flex items-center gap-2 py-3 px-3 border-b-2 font-medium text-xs sm:text-sm whitespace-nowrap transition-colors ${
              currentView === 'customizer'
                ? 'border-red-500 text-red-400 font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-600'
            }`}
          >
            <Settings className="w-4 h-4" />
            <span>acad.pgp Customizer &amp; Parser</span>
          </button>
        </div>
      </div>
    </header>
  );
};
