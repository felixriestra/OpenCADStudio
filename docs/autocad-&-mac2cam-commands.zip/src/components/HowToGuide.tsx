import React, { useState } from 'react';
import { 
  BookOpen, 
  Terminal, 
  FileCode, 
  RefreshCw, 
  Sliders, 
  ExternalLink, 
  Copy, 
  Check, 
  FileSpreadsheet, 
  Layers, 
  ShieldCheck, 
  Code 
} from 'lucide-react';

export const HowToGuide: React.FC = () => {
  const [copiedSnippet, setCopiedSnippet] = useState<string | null>(null);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSnippet(id);
    setTimeout(() => setCopiedSnippet(null), 1800);
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Hero Overview */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-red-600 mb-2">
          <BookOpen className="w-4 h-4" />
          <span>Autodesk Knowledge Reference</span>
        </div>
        <h2 className="text-2xl font-bold text-slate-900 tracking-tight">
          How AutoCAD Command Aliases Work &amp; How to Create a Structured Joined Table
        </h2>
        <p className="text-sm text-slate-600 mt-2 leading-relaxed">
          Based on the Autodesk AutoCAD guide (
          <a
            href="https://www.autodesk.com/blogs/autocad/autocad-command-aliases/"
            target="_blank"
            rel="noopener noreferrer"
            className="text-red-600 font-medium hover:underline inline-flex items-center gap-0.5"
          >
            autodesk.com/blogs/autocad/autocad-command-aliases
            <ExternalLink className="w-3 h-3 ml-0.5" />
          </a>
          ), command aliases are shortened abbreviations that trigger AutoCAD commands from the command line. This guide summarizes how aliases are defined, how AutoCAD processes them, and the exact steps to extract and join them into a structured reference document.
        </p>
      </div>

      {/* Part 1: Core Concepts from Autodesk */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-6">
        <h3 className="text-lg font-bold text-slate-900 border-b border-slate-200 pb-3 flex items-center gap-2">
          <Terminal className="w-5 h-5 text-red-600" />
          <span>Part 1: The Two Ways to Manage Aliases in AutoCAD</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Method A: ALIASEDIT */}
          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/70 space-y-3">
            <div className="flex items-center justify-between">
              <span className="px-2.5 py-1 rounded bg-slate-900 text-white font-mono text-xs font-bold">
                ALIASEDIT
              </span>
              <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded">
                Express Tools GUI
              </span>
            </div>
            <h4 className="font-bold text-sm text-slate-800">The Visual Alias Editor</h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              AutoCAD includes a dedicated Express Tool dialog box for managing aliases without needing to touch raw files:
            </p>
            <ol className="text-xs text-slate-700 space-y-1.5 list-decimal list-inside pl-1">
              <li>Type <code className="font-mono font-bold bg-slate-200 px-1 py-0.5 rounded">ALIASEDIT</code> at the command prompt and hit <kbd className="font-mono bg-white px-1 border rounded">Enter</kbd>.</li>
              <li>The <strong>AutoCAD Alias Editor</strong> dialog lists all active aliases and their commands.</li>
              <li>Click <strong>Add</strong> to define a new alias, <strong>Edit</strong> to change one, or <strong>Remove</strong> to delete.</li>
              <li>Click <strong>Apply</strong> and confirm to save changes directly to <code className="font-mono text-[11px]">acad.pgp</code>.</li>
            </ol>
            <div className="text-[11px] text-slate-500 bg-white p-2.5 rounded border border-slate-200">
              <strong>Note:</strong> <code className="font-mono">ALIASEDIT</code> is part of Express Tools (available in full AutoCAD, but not AutoCAD LT).
            </div>
          </div>

          {/* Method B: Direct acad.pgp editing */}
          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/70 space-y-3">
            <div className="flex items-center justify-between">
              <span className="px-2.5 py-1 rounded bg-slate-900 text-white font-mono text-xs font-bold">
                acad.pgp
              </span>
              <span className="text-xs font-semibold text-blue-700 bg-blue-50 border border-blue-200 px-2 py-0.5 rounded">
                Text Configuration
              </span>
            </div>
            <h4 className="font-bold text-sm text-slate-800">Editing acad.pgp Directly</h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Command aliases are stored in a plain-text file called <code className="font-mono">acad.pgp</code> (or <code className="font-mono">acadlt.pgp</code> for AutoCAD LT):
            </p>
            <ul className="text-xs text-slate-700 space-y-1.5 list-disc list-inside pl-1">
              <li>Open directly in AutoCAD: Ribbon <strong>Manage</strong> tab &rarr; <strong>Customization</strong> &rarr; <strong>Edit Aliases</strong>.</li>
              <li>Or type <code className="font-mono bg-slate-200 px-1 py-0.5 rounded">AI_EDITCUSTFILE</code> &rarr; enter <code className="font-mono bg-slate-200 px-1 py-0.5 rounded">acad.pgp</code>.</li>
              <li>Or open the file in Windows Notepad from your roaming AppData support directory.</li>
            </ul>
            <div className="text-[11px] text-slate-500 bg-white p-2.5 rounded border border-slate-200">
              <strong>Path:</strong> <code className="font-mono text-[10px] break-all">C:\Users\&lt;user&gt;\AppData\Roaming\Autodesk\AutoCAD 20xx\Rxx\&lt;lang&gt;\Support\acad.pgp</code>
            </div>
          </div>
        </div>

        {/* Syntax & Precedence Rules */}
        <div className="border-t border-slate-200 pt-5 space-y-4">
          <h4 className="text-sm font-bold text-slate-900">
            The Two Golden Rules of AutoCAD Aliases
          </h4>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Rule 1: Syntax */}
            <div className="bg-slate-900 text-slate-100 rounded-lg p-4 font-mono text-xs space-y-2">
              <div className="text-slate-400 font-sans font-semibold text-xs flex items-center justify-between">
                <span>Rule 1: Exact Syntax Format</span>
                <span className="text-emerald-400 font-mono">ALIAS, *COMMAND</span>
              </div>
              <div className="bg-slate-950 p-3 rounded text-slate-300 space-y-1 text-[11px]">
                <p><span className="text-slate-500">; Syntax: [Abbreviation], *[Full AutoCAD Command]</span></p>
                <p><span className="text-amber-400">L</span>,      *<span className="text-emerald-400">LINE</span></p>
                <p><span className="text-amber-400">C</span>,      *<span className="text-emerald-400">CIRCLE</span></p>
                <p><span className="text-amber-400">CC</span>,     *<span className="text-emerald-400">COPY</span> <span className="text-slate-500">; Custom double-C copy alias</span></p>
                <p><span className="text-amber-400">ZA</span>,     *<span className="text-emerald-400">ZOOM</span> <span className="text-slate-500">; Custom alias</span></p>
              </div>
              <p className="text-slate-400 font-sans text-[11px]">
                An asterisk <code className="text-amber-300 font-mono">*</code> MUST precede the command name. Lines starting with a semicolon <code className="text-amber-300 font-mono">;</code> are comments.
              </p>
            </div>

            {/* Rule 2: Precedence and REINIT */}
            <div className="border border-slate-200 rounded-lg p-4 text-xs space-y-3 bg-amber-50/50">
              <div className="font-semibold text-slate-900 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-amber-600" />
                <span>Rule 2: Put Custom Aliases at the Bottom</span>
              </div>
              <p className="text-slate-700 leading-relaxed">
                AutoCAD reads <code className="font-mono bg-white px-1 py-0.5 border rounded">acad.pgp</code> sequentially from top to bottom. If an alias is defined twice, <strong>the LAST definition wins</strong>.
              </p>
              <div className="bg-white p-2.5 rounded border border-amber-200 text-[11px] text-slate-800">
                Always place your custom shortcuts at the very bottom under the <strong>-- User Defined Command Aliases --</strong> header. This ensures your shortcuts take priority over defaults and makes migrations to newer AutoCAD versions effortless!
              </div>
              <div className="flex items-center gap-2 pt-1">
                <RefreshCw className="w-4 h-4 text-slate-700 shrink-0" />
                <span className="text-slate-700">
                  Reload without restarting: type <code className="font-mono font-bold bg-white px-1 py-0.5 border rounded">REINIT</code> &rarr; check <strong>PGP File</strong> &rarr; click OK.
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Part 2: How to Join All Aliases into a Structured Document */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-6">
        <h3 className="text-lg font-bold text-slate-900 border-b border-slate-200 pb-3 flex items-center gap-2">
          <Layers className="w-5 h-5 text-red-600" />
          <span>Part 2: How to Create a Table Joining All Command Aliases</span>
        </h3>

        <p className="text-sm text-slate-600 leading-relaxed">
          The user prompt specifically asked <em>"how to create a table joining all the command aliases that summarizes the shortcuts into a structured document for easy reference"</em>. Here is the exact architectural pipeline used to construct the joined table in this application:
        </p>

        {/* 4 Step Workflow */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50 space-y-1.5">
            <span className="w-6 h-6 rounded-full bg-slate-900 text-white font-bold text-xs flex items-center justify-center">
              1
            </span>
            <h5 className="font-bold text-xs text-slate-900">Extract Source PGP</h5>
            <p className="text-[11px] text-slate-600 leading-relaxed">
              Read the raw <code className="font-mono">acad.pgp</code> file from the AutoCAD Support directory or extract standard commands.
            </p>
          </div>

          <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50 space-y-1.5">
            <span className="w-6 h-6 rounded-full bg-slate-900 text-white font-bold text-xs flex items-center justify-center">
              2
            </span>
            <h5 className="font-bold text-xs text-slate-900">Parse &amp; Clean</h5>
            <p className="text-[11px] text-slate-600 leading-relaxed">
              Filter out semicolon comments <code className="font-mono">;</code>, split on comma <code className="font-mono">,</code>, and strip the asterisk <code className="font-mono">*</code> prefix.
            </p>
          </div>

          <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50 space-y-1.5">
            <span className="w-6 h-6 rounded-full bg-slate-900 text-white font-bold text-xs flex items-center justify-center">
              3
            </span>
            <h5 className="font-bold text-xs text-slate-900">Join Metadata</h5>
            <p className="text-[11px] text-slate-600 leading-relaxed">
              Join the command names against a drafting dictionary with Category (Draw, Modify, Dimension), Description, and Drafter tips.
            </p>
          </div>

          <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50 space-y-1.5">
            <span className="w-6 h-6 rounded-full bg-slate-900 text-white font-bold text-xs flex items-center justify-center">
              4
            </span>
            <h5 className="font-bold text-xs text-slate-900">Export Structured Doc</h5>
            <p className="text-[11px] text-slate-600 leading-relaxed">
              Render as an interactive searchable table, a printable PDF cheat sheet, or export to CSV / Excel and Markdown.
            </p>
          </div>
        </div>

        {/* Code Snippets for Parsing */}
        <div className="space-y-4 pt-2">
          <h4 className="text-sm font-bold text-slate-900 flex items-center justify-between">
            <span>Automated Scripts to Parse acad.pgp into a Table</span>
            <span className="text-xs text-slate-500 font-normal">Choose your preferred method</span>
          </h4>

          {/* Option A: Python / Node Parser */}
          <div className="bg-slate-900 rounded-xl overflow-hidden border border-slate-800">
            <div className="bg-slate-950 px-4 py-2 border-b border-slate-800 flex items-center justify-between">
              <span className="text-xs font-mono text-slate-400 flex items-center gap-1.5">
                <Code className="w-3.5 h-3.5 text-blue-400" />
                <span>Python Script: parse_pgp_to_csv.py</span>
              </span>
              <button
                onClick={() =>
                  handleCopy(
                    `import re, csv

pgp_path = 'acad.pgp'
output_csv = 'autocad_shortcuts_table.csv'

# Pattern matches: ALIAS, *COMMAND
pattern = re.compile(r'^\\s*([A-Za-z0-9_-]+)\\s*,\\s*\\*([A-Za-z0-9_-]+)', re.IGNORECASE)

records = []
with open(pgp_path, 'r', encoding='utf-8', errors='ignore') as f:
    for line in f:
        line = line.strip()
        if not line or line.startswith(';'):
            continue
        match = pattern.match(line)
        if match:
            alias, command = match.groups()
            records.append({'Alias': alias.upper(), 'Command': command.upper()})

with open(output_csv, 'w', newline='', encoding='utf-8') as f:
    writer = csv.DictWriter(f, fieldnames=['Alias', 'Command'])
    writer.writeheader()
    writer.writerows(records)

print(f"Extracted {len(records)} command aliases into {output_csv}")`,
                    'py-code'
                  )
                }
                className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-mono transition-colors"
              >
                {copiedSnippet === 'py-code' ? (
                  <>
                    <Check className="w-3 h-3 text-emerald-400" />
                    <span>Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3 h-3" />
                    <span>Copy Code</span>
                  </>
                )}
              </button>
            </div>
            <pre className="p-4 text-xs font-mono text-slate-300 overflow-x-auto leading-relaxed">
              <code>{`import re, csv

pgp_path = 'acad.pgp'
output_csv = 'autocad_shortcuts_table.csv'

# Regex pattern matches: ALIAS, *COMMAND
pattern = re.compile(r'^\\s*([A-Za-z0-9_-]+)\\s*,\\s*\\*([A-Za-z0-9_-]+)', re.IGNORECASE)

records = []
with open(pgp_path, 'r', encoding='utf-8', errors='ignore') as f:
    for line in f:
        line = line.strip()
        if not line or line.startswith(';'):
            continue
        match = pattern.match(line)
        if match:
            alias, command = match.groups()
            records.append({'Alias': alias.upper(), 'Command': command.upper()})

with open(output_csv, 'w', newline='', encoding='utf-8') as f:
    writer = csv.DictWriter(f, fieldnames=['Alias', 'Command'])
    writer.writeheader()
    writer.writerows(records)

print(f"Extracted {len(records)} command aliases into {output_csv}")`}</code>
            </pre>
          </div>

          {/* Option B: Direct Excel / Google Sheets Import */}
          <div className="p-4 rounded-lg border border-slate-200 bg-slate-50 space-y-2">
            <h5 className="font-bold text-xs text-slate-900 flex items-center gap-1.5">
              <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
              <span>Importing Directly into Microsoft Excel or Google Sheets</span>
            </h5>
            <ol className="text-xs text-slate-700 space-y-1 list-decimal list-inside pl-1 leading-relaxed">
              <li>Open Excel &rarr; <strong>Data</strong> &rarr; <strong>From Text/CSV</strong> &rarr; select <code className="font-mono">acad.pgp</code>.</li>
              <li>Set Delimiter to <strong>Comma</strong>. Excel will place aliases in Column A and full commands in Column B.</li>
              <li>Use <strong>Find &amp; Replace</strong> on Column B to replace the asterisk <code className="font-mono bg-white px-1 border rounded">*</code> with nothing.</li>
              <li>Filter out rows beginning with a semicolon <code className="font-mono bg-white px-1 border rounded">;</code> (header comments).</li>
              <li>Sort Column A by length or alphabetical order to create your custom company drafting table!</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  );
};
