import React, { useState, useMemo } from 'react';
import { AutoCADAlias, CommandCategory, FilterState } from '../types';
import { CATEGORY_COLORS } from '../data/aliasesData';
import { SysVarsSection } from './SysVarsSection';
import { ExtendedCommandSections } from './ExtendedCommandSections';
import { Mac2CamCustomSection } from './Mac2CamCustomSection';
import { 
  Search, 
  Copy, 
  Check, 
  ArrowUpDown, 
  ArrowUp, 
  ArrowDown, 
  X, 
  Sparkles,
  ChevronRight,
  Command,
  SlidersHorizontal,
  PlusCircle,
  HelpCircle
} from 'lucide-react';

interface AliasTableProps {
  aliases: AutoCADAlias[];
  onSelectAlias?: (alias: AutoCADAlias) => void;
}

const CATEGORIES: (CommandCategory | 'All')[] = [
  'All',
  'Draw',
  'Modify',
  'Dimension',
  'Annotation',
  'Layers & Properties',
  'View & Navigation',
  'Blocks & References',
  'Inquiry & Measure',
  '3D Modeling',
  'System & Utilities',
];

export const AliasTable: React.FC<AliasTableProps> = ({ aliases }) => {
  const [filter, setFilter] = useState<FilterState>({
    search: '',
    category: 'All',
    aliasStatus: 'All',
    keyType: 'All',
    frequency: 'All',
    sortBy: 'alias',
    sortOrder: 'asc',
  });

  const [selectedAlias, setSelectedAlias] = useState<AutoCADAlias | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCopy = (text: string, id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => {
      setCopiedId(null);
    }, 1800);
  };

  const handleSort = (field: FilterState['sortBy']) => {
    setFilter((prev) => ({
      ...prev,
      sortBy: field,
      sortOrder: prev.sortBy === field && prev.sortOrder === 'asc' ? 'desc' : 'asc',
    }));
  };

  // Counts
  const totalCount = aliases.length;
  const hasAliasCount = useMemo(() => aliases.filter((a) => a.hasDefaultAlias).length, [aliases]);
  const noAliasCount = useMemo(() => aliases.filter((a) => !a.hasDefaultAlias).length, [aliases]);

  // Filter and sort items
  const filteredAliases = useMemo(() => {
    const q = filter.search.toLowerCase().trim();

    return aliases
      .filter((item) => {
        // Alias Status filter
        if (filter.aliasStatus === 'Has-Alias' && !item.hasDefaultAlias) {
          return false;
        }
        if (filter.aliasStatus === 'No-Alias' && item.hasDefaultAlias) {
          return false;
        }

        // Category filter
        if (filter.category !== 'All' && item.category !== filter.category) {
          return false;
        }

        // Frequency filter
        if (filter.frequency !== 'All' && item.frequency !== filter.frequency) {
          return false;
        }

        // Key length / type filter
        if (filter.keyType !== 'All') {
          if (!item.hasDefaultAlias) {
            return false;
          }
          if (filter.keyType === 'Single-Key' && !item.isSingleKey) {
            return false;
          }
          if (filter.keyType === '2-Letter' && item.alias.length !== 2) {
            return false;
          }
          if (filter.keyType === '3+ Letter' && item.alias.length < 3) {
            return false;
          }
          if (filter.keyType === 'Numbers' && !/\d/.test(item.alias)) {
            return false;
          }
        }

        // Search text
        if (q) {
          const matchAlias = item.alias ? item.alias.toLowerCase().includes(q) : false;
          const matchSuggested = item.suggestedAlias ? item.suggestedAlias.toLowerCase().includes(q) : false;
          const matchCommand = item.command.toLowerCase().includes(q);
          const matchDesc = item.description.toLowerCase().includes(q);
          const matchTag = item.tags.some((t) => t.toLowerCase().includes(q));
          const matchTips = item.tips ? item.tips.toLowerCase().includes(q) : false;
          if (!matchAlias && !matchSuggested && !matchCommand && !matchDesc && !matchTag && !matchTips) {
            return false;
          }
        }

        return true;
      })
      .sort((a, b) => {
        let compare = 0;
        if (filter.sortBy === 'alias') {
          const aVal = a.alias || (a.suggestedAlias ? `~${a.suggestedAlias}` : '~~~');
          const bVal = b.alias || (b.suggestedAlias ? `~${b.suggestedAlias}` : '~~~');
          compare = aVal.localeCompare(bVal);
        } else if (filter.sortBy === 'command') {
          compare = a.command.localeCompare(b.command);
        } else if (filter.sortBy === 'category') {
          compare = a.category.localeCompare(b.category);
        } else if (filter.sortBy === 'frequency') {
          const rank = { Essential: 3, Common: 2, Advanced: 1 };
          compare = (rank[b.frequency] || 0) - (rank[a.frequency] || 0);
        }

        return filter.sortOrder === 'asc' ? compare : -compare;
      });
  }, [aliases, filter]);

  // Counts per category
  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = { All: aliases.length };
    aliases.forEach((a) => {
      counts[a.category] = (counts[a.category] || 0) + 1;
    });
    return counts;
  }, [aliases]);

  return (
    <div className="space-y-4">
      {/* Search and Quick Filters Card */}
      <div className="bg-white rounded-xl shadow-xs border border-slate-200 p-4">
        {/* Top filter row */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-center">
          {/* Search bar */}
          <div className="md:col-span-6 relative">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              id="alias-search-input"
              type="text"
              value={filter.search}
              onChange={(e) => setFilter({ ...filter, search: e.target.value })}
              placeholder="Search all commands (e.g. OVERKILL, LINE, CHSPACE), aliases (L, REC), or keywords..."
              className="w-full pl-9 pr-9 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500 bg-slate-50/50 hover:bg-white transition-colors"
            />
            {filter.search && (
              <button
                onClick={() => setFilter({ ...filter, search: '' })}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Key Length Filter */}
          <div className="md:col-span-3">
            <div className="flex items-center rounded-lg border border-slate-200 p-0.5 bg-slate-100 text-xs">
              {(['All', 'Single-Key', '2-Letter', '3+ Letter'] as const).map((type) => (
                <button
                  key={type}
                  onClick={() => setFilter({ ...filter, keyType: type })}
                  className={`flex-1 py-1 px-1.5 rounded-md font-medium text-center transition-all ${
                    filter.keyType === type
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {type === 'Single-Key' ? '1-Key' : type}
                </button>
              ))}
            </div>
          </div>

          {/* Frequency Filter */}
          <div className="md:col-span-3 flex items-center justify-between gap-2">
            <select
              value={filter.frequency}
              onChange={(e) => setFilter({ ...filter, frequency: e.target.value as any })}
              className="w-full py-2 px-3 rounded-lg border border-slate-200 text-xs font-medium text-slate-700 bg-white focus:outline-none focus:ring-2 focus:ring-red-500"
            >
              <option value="All">All Importance Levels</option>
              <option value="Essential">Essential Only (High Frequency)</option>
              <option value="Common">Commonly Used</option>
              <option value="Advanced">Specialized / Advanced</option>
            </select>
          </div>
        </div>

        {/* Alias Status Quick Tabs (All Commands vs Has Alias vs No Default Alias) */}
        <div className="mt-3 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 p-0.5 bg-slate-100 rounded-lg border border-slate-200 text-xs font-medium">
            <button
              onClick={() => setFilter({ ...filter, aliasStatus: 'All' })}
              className={`px-3 py-1 rounded-md transition-all ${
                filter.aliasStatus === 'All'
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All AutoCAD Commands ({totalCount})
            </button>
            <button
              onClick={() => setFilter({ ...filter, aliasStatus: 'Has-Alias' })}
              className={`px-3 py-1 rounded-md transition-all flex items-center gap-1.5 ${
                filter.aliasStatus === 'Has-Alias'
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <span>Default Aliases</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-emerald-100 text-emerald-800 font-bold">
                {hasAliasCount}
              </span>
            </button>
            <button
              onClick={() => setFilter({ ...filter, aliasStatus: 'No-Alias' })}
              className={`px-3 py-1 rounded-md transition-all flex items-center gap-1.5 ${
                filter.aliasStatus === 'No-Alias'
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <span>Full Command Only (No Default Alias)</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-slate-200 text-slate-700 font-bold">
                {noAliasCount}
              </span>
            </button>
          </div>

          <div className="text-[11px] text-slate-500 hidden sm:block">
            Includes both stock <code className="font-mono text-slate-700">acad.pgp</code> shortcuts and commands requiring full name
          </div>
        </div>

        {/* Category Pills */}
        <div className="mt-3 pt-3 border-t border-slate-100 flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
          {CATEGORIES.map((cat) => {
            const count = categoryCounts[cat] || 0;
            const isSelected = filter.category === cat;
            return (
              <button
                key={cat}
                onClick={() => setFilter({ ...filter, category: cat })}
                className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium whitespace-nowrap transition-all ${
                  isSelected
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                <span>{cat}</span>
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                    isSelected ? 'bg-slate-700 text-slate-200' : 'bg-slate-200 text-slate-600'
                  }`}
                >
                  {count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Results Header with stats and sorting status */}
      <div className="flex items-center justify-between text-xs text-slate-500 px-1">
        <div>
          Showing <span className="font-semibold text-slate-900">{filteredAliases.length}</span> commands
          {filter.aliasStatus === 'Has-Alias' && ' with default shortcuts'}
          {filter.aliasStatus === 'No-Alias' && ' without default shortcuts'}
          {filter.search && ` matching "${filter.search}"`}
          {filter.category !== 'All' && ` in ${filter.category}`}
        </div>
        <div className="flex items-center gap-2">
          <span className="hidden sm:inline">Click any row for acad.pgp syntax, custom code snippet, &amp; drafting tips</span>
        </div>
      </div>

      {/* Main Table */}
      <div className="bg-white rounded-xl shadow-xs border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm border-collapse" id="autocad-aliases-table">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-xs uppercase tracking-wider text-slate-500 font-semibold select-none">
                <th
                  onClick={() => handleSort('alias')}
                  className="py-3 px-4 cursor-pointer hover:bg-slate-100 transition-colors w-32"
                >
                  <div className="flex items-center gap-1.5">
                    <span>Alias / Shortcut</span>
                    {filter.sortBy === 'alias' ? (
                      filter.sortOrder === 'asc' ? <ArrowUp className="w-3.5 h-3.5 text-red-600" /> : <ArrowDown className="w-3.5 h-3.5 text-red-600" />
                    ) : (
                      <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
                    )}
                  </div>
                </th>
                <th
                  onClick={() => handleSort('command')}
                  className="py-3 px-4 cursor-pointer hover:bg-slate-100 transition-colors w-44"
                >
                  <div className="flex items-center gap-1.5">
                    <span>AutoCAD Command</span>
                    {filter.sortBy === 'command' ? (
                      filter.sortOrder === 'asc' ? <ArrowUp className="w-3.5 h-3.5 text-red-600" /> : <ArrowDown className="w-3.5 h-3.5 text-red-600" />
                    ) : (
                      <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
                    )}
                  </div>
                </th>
                <th
                  onClick={() => handleSort('category')}
                  className="py-3 px-4 cursor-pointer hover:bg-slate-100 transition-colors hidden sm:table-cell w-36"
                >
                  <div className="flex items-center gap-1.5">
                    <span>Category</span>
                    {filter.sortBy === 'category' ? (
                      filter.sortOrder === 'asc' ? <ArrowUp className="w-3.5 h-3.5 text-red-600" /> : <ArrowDown className="w-3.5 h-3.5 text-red-600" />
                    ) : (
                      <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
                    )}
                  </div>
                </th>
                <th className="py-3 px-4 hidden md:table-cell w-48">
                  <span>acad.pgp Syntax</span>
                </th>
                <th className="py-3 px-4">
                  <span>Description &amp; Drafting Tips</span>
                </th>
                <th className="py-3 px-4 text-right w-24">
                  <span>Action</span>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredAliases.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-500">
                    <p className="text-sm font-medium">No AutoCAD commands found matching your filters</p>
                    <button
                      onClick={() =>
                        setFilter({
                          search: '',
                          category: 'All',
                          aliasStatus: 'All',
                          keyType: 'All',
                          frequency: 'All',
                          sortBy: 'alias',
                          sortOrder: 'asc',
                        })
                      }
                      className="mt-2 text-xs font-semibold text-red-600 hover:text-red-700 underline"
                    >
                      Clear all filters
                    </button>
                  </td>
                </tr>
              ) : (
                filteredAliases.map((item) => {
                  const catStyle = CATEGORY_COLORS[item.category] || CATEGORY_COLORS['System & Utilities'];
                  return (
                    <tr
                      key={item.id}
                      onClick={() => setSelectedAlias(item)}
                      className="hover:bg-slate-50/80 cursor-pointer transition-colors group"
                    >
                      {/* Alias / Shortcut */}
                      <td className="py-3 px-4 font-mono font-bold text-slate-900">
                        {item.hasDefaultAlias ? (
                          <div className="flex items-center gap-2">
                            <span
                              className={`inline-flex items-center justify-center min-w-[2.2rem] h-7 px-1.5 rounded text-xs font-mono font-black tracking-wide border shadow-2xs ${
                                item.isSingleKey
                                  ? 'bg-amber-50 text-amber-900 border-amber-300 ring-1 ring-amber-200/50'
                                  : 'bg-slate-100 text-slate-900 border-slate-300'
                              }`}
                            >
                              {item.alias}
                            </span>
                            {item.isSingleKey && (
                              <span className="hidden lg:inline text-[10px] uppercase font-bold text-amber-600 px-1 py-0.2 rounded bg-amber-50">
                                1-key
                              </span>
                            )}
                          </div>
                        ) : (
                          <div className="flex flex-col gap-0.5">
                            <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-slate-100 text-slate-500 border border-dashed border-slate-300 w-fit">
                              None
                            </span>
                            {item.suggestedAlias && (
                              <span className="text-[10px] text-slate-500 font-sans">
                                Rec: <span className="font-mono font-bold text-indigo-600 bg-indigo-50 px-1 rounded">{item.suggestedAlias}</span>
                              </span>
                            )}
                          </div>
                        )}
                      </td>

                      {/* Full Command */}
                      <td className="py-3 px-4 font-medium text-slate-800 font-mono text-xs sm:text-sm">
                        <span className="font-semibold text-slate-900">{item.command}</span>
                      </td>

                      {/* Category */}
                      <td className="py-3 px-4 hidden sm:table-cell">
                        <span
                          className={`inline-block px-2 py-0.5 rounded text-xs font-medium border ${catStyle.bg}`}
                        >
                          {item.category}
                        </span>
                      </td>

                      {/* acad.pgp syntax */}
                      <td className="py-3 px-4 hidden md:table-cell font-mono text-xs text-slate-600">
                        <div className="flex items-center gap-1.5">
                          <code
                            className={`px-2 py-0.5 rounded border text-[11px] ${
                              item.hasDefaultAlias
                                ? 'bg-slate-100 text-slate-700 border-slate-200'
                                : 'bg-slate-50 text-slate-500 border-dashed border-slate-300'
                            }`}
                          >
                            {item.hasDefaultAlias ? item.syntax : `${item.suggestedAlias || 'CUSTOM'}, *${item.command}`}
                          </code>
                          <button
                            onClick={(e) => {
                              const textToCopy = item.hasDefaultAlias
                                ? item.syntax
                                : `${item.suggestedAlias || 'CUSTOM'}, *${item.command}`;
                              handleCopy(textToCopy, `pgp-${item.id}`, e);
                            }}
                            title="Copy acad.pgp definition"
                            className="p-1 rounded text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition-colors opacity-0 group-hover:opacity-100"
                          >
                            {copiedId === `pgp-${item.id}` ? (
                              <Check className="w-3.5 h-3.5 text-emerald-600" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </div>
                      </td>

                      {/* Description & Tips */}
                      <td className="py-3 px-4 text-xs text-slate-600 leading-relaxed">
                        <div className="font-normal text-slate-800">{item.description}</div>
                        {item.tips && (
                          <div className="text-[11px] text-slate-500 mt-0.5 line-clamp-1 italic">
                            <span className="font-medium text-slate-600 not-italic">Tip: </span>
                            {item.tips}
                          </div>
                        )}
                      </td>

                      {/* Action */}
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={(e) => {
                              const text = item.hasDefaultAlias ? item.alias : item.command;
                              handleCopy(text, `alias-${item.id}`, e);
                            }}
                            className="p-1.5 rounded-md hover:bg-slate-200 text-slate-500 hover:text-slate-800 transition-colors"
                            title={item.hasDefaultAlias ? `Copy shortcut '${item.alias}'` : `Copy command '${item.command}'`}
                          >
                            {copiedId === `alias-${item.id}` ? (
                              <Check className="w-4 h-4 text-emerald-600" />
                            ) : (
                              <Copy className="w-4 h-4" />
                            )}
                          </button>
                          <ChevronRight className="w-4 h-4 text-slate-300 group-hover:text-slate-600 transition-colors" />
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* AutoCAD System Variables Section */}
      <SysVarsSection />

      {/* Mac2CAM Extended Registry (Duplicates, Meta Primitives, 3D/Mesh) */}
      <ExtendedCommandSections />

      {/* Mac2CAM Custom & Extended Commands Section */}
      <Mac2CamCustomSection />

      {/* Detailed Modal/Drawer for Selected Alias */}
      {selectedAlias && (
        <div
          className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-50 flex items-center justify-center p-4"
          onClick={() => setSelectedAlias(null)}
        >
          <div
            className="bg-white rounded-xl shadow-xl border border-slate-200 max-w-lg w-full overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="bg-slate-900 text-white p-5 flex items-start justify-between">
              <div>
                <div className="flex items-center gap-3">
                  {selectedAlias.hasDefaultAlias ? (
                    <span className="px-2.5 py-1 rounded bg-red-600 text-white font-mono font-black text-lg tracking-wider shadow-inner">
                      {selectedAlias.alias}
                    </span>
                  ) : (
                    <span className="px-2.5 py-1 rounded bg-slate-800 text-slate-300 font-mono text-xs border border-slate-700">
                      No Default Alias
                    </span>
                  )}
                  <div>
                    <h3 className="text-xl font-bold font-mono text-white">{selectedAlias.command}</h3>
                    <p className="text-xs text-slate-400">
                      {selectedAlias.hasDefaultAlias ? 'AutoCAD Stock Command Alias' : 'AutoCAD Full Command (Unaliased)'}
                    </p>
                  </div>
                </div>
              </div>
              <button
                onClick={() => setSelectedAlias(null)}
                className="text-slate-400 hover:text-white p-1 rounded-md"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 space-y-5 text-sm">
              {/* Category & Attributes */}
              <div className="flex items-center gap-2 flex-wrap">
                <span
                  className={`px-2.5 py-0.5 rounded-full text-xs font-semibold border ${
                    CATEGORY_COLORS[selectedAlias.category]?.bg || 'bg-slate-100 text-slate-700'
                  }`}
                >
                  {selectedAlias.category}
                </span>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-700 border border-slate-200">
                  {selectedAlias.frequency} Frequency
                </span>
                {selectedAlias.isSingleKey && (
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-800 border border-amber-200">
                    ★ 1-Key Priority Shortcut
                  </span>
                )}
                {!selectedAlias.hasDefaultAlias && (
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-50 text-indigo-700 border border-indigo-200">
                    Customizable in acad.pgp
                  </span>
                )}
              </div>

              {/* Description */}
              <div>
                <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">
                  Description
                </h4>
                <p className="text-slate-800 leading-relaxed">{selectedAlias.description}</p>
              </div>

              {/* acad.pgp syntax box */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                    {selectedAlias.hasDefaultAlias ? 'acad.pgp File Format' : 'Recommended acad.pgp Definition'}
                  </h4>
                  <span className="text-[11px] text-slate-400">Syntax: ALIAS, *COMMAND</span>
                </div>
                <div className="bg-slate-900 rounded-lg p-3 flex items-center justify-between font-mono text-xs text-emerald-400 border border-slate-800">
                  <code>
                    {selectedAlias.hasDefaultAlias
                      ? selectedAlias.syntax
                      : `${selectedAlias.suggestedAlias || 'CUSTOM'}, *${selectedAlias.command}`}
                  </code>
                  <button
                    onClick={(e) => {
                      const text = selectedAlias.hasDefaultAlias
                        ? selectedAlias.syntax
                        : `${selectedAlias.suggestedAlias || 'CUSTOM'}, *${selectedAlias.command}`;
                      handleCopy(text, 'modal-pgp', e);
                    }}
                    className="inline-flex items-center gap-1.5 px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs transition-colors"
                  >
                    {copiedId === 'modal-pgp' ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy Line</span>
                      </>
                    )}
                  </button>
                </div>
                {!selectedAlias.hasDefaultAlias && (
                  <p className="text-[11px] text-slate-500 mt-1">
                    Add this line to the <strong>User Defined Command Aliases</strong> section at the end of your <code className="text-slate-700 font-mono">acad.pgp</code> file, then run <code className="text-slate-700 font-mono">REINIT</code>.
                  </p>
                )}
              </div>

              {/* Tips */}
              {selectedAlias.tips && (
                <div className="bg-amber-50/70 border border-amber-200/80 rounded-lg p-3 text-amber-900 text-xs leading-relaxed">
                  <div className="font-semibold text-amber-800 flex items-center gap-1.5 mb-0.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                    <span>Power Drafter Tip</span>
                  </div>
                  <p>{selectedAlias.tips}</p>
                </div>
              )}

              {/* Tags */}
              <div>
                <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
                  Related Keywords
                </h4>
                <div className="flex flex-wrap gap-1.5">
                  {selectedAlias.tags.map((t) => (
                    <span
                      key={t}
                      className="px-2 py-0.5 rounded text-[11px] bg-slate-100 text-slate-600 font-mono"
                    >
                      #{t}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="bg-slate-50 border-t border-slate-100 px-6 py-3 flex items-center justify-between text-xs">
              <span className="text-slate-500">Press Esc or click outside to close</span>
              <button
                onClick={() => setSelectedAlias(null)}
                className="px-4 py-1.5 rounded-md bg-slate-200 hover:bg-slate-300 font-medium text-slate-800 transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
