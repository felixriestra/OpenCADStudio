import React, { useState, useMemo } from 'react';
import { 
  DUPLICATE_ALIAS_COMMANDS, 
  APPLICATION_META_COMMANDS, 
  THREE_D_NON_EXEC_COMMANDS,
  DuplicateAliasCommand,
  AppMetaCommand,
  ThreeDNonExecCommand
} from '../data/extendedCommandsData';
import { 
  CopyCheck, 
  Layers, 
  Box, 
  Search, 
  Copy, 
  Check, 
  Info, 
  AlertTriangle, 
  ChevronDown, 
  ChevronRight,
  ExternalLink,
  Terminal,
  Cpu
} from 'lucide-react';

interface ExtendedCommandSectionsProps {
  initialSubTab?: 'all' | 'duplicates' | 'meta' | 'threed';
}

export const ExtendedCommandSections: React.FC<ExtendedCommandSectionsProps> = ({ initialSubTab = 'all' }) => {
  const [activeSection, setActiveSection] = useState<'all' | 'duplicates' | 'meta' | 'threed'>(initialSubTab);
  const [search, setSearch] = useState('');
  const [copiedToken, setCopiedToken] = useState<string | null>(null);

  // Collapsible toggle states
  const [isDupOpen, setIsDupOpen] = useState(true);
  const [isMetaOpen, setIsMetaOpen] = useState(true);
  const [isThreeDOpen, setIsThreeDOpen] = useState(true);

  const handleCopy = (text: string, id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(text);
    setCopiedToken(id);
    setTimeout(() => setCopiedToken(null), 1800);
  };

  const q = search.toLowerCase().trim();

  const filteredDuplicates = useMemo(() => {
    if (!q) return DUPLICATE_ALIAS_COMMANDS;
    return DUPLICATE_ALIAS_COMMANDS.filter(
      (d) =>
        d.aliasToken.toLowerCase().includes(q) ||
        d.targetCommand.toLowerCase().includes(q) ||
        d.category.toLowerCase().includes(q) ||
        d.reasonForSeparateRegistration.toLowerCase().includes(q)
    );
  }, [q]);

  const filteredMeta = useMemo(() => {
    if (!q) return APPLICATION_META_COMMANDS;
    return APPLICATION_META_COMMANDS.filter(
      (m) =>
        m.token.toLowerCase().includes(q) ||
        m.actionType.toLowerCase().includes(q) ||
        m.description.toLowerCase().includes(q) ||
        m.mac2camBehavior.toLowerCase().includes(q) ||
        m.autocadBehavior.toLowerCase().includes(q)
    );
  }, [q]);

  const filteredThreeD = useMemo(() => {
    if (!q) return THREE_D_NON_EXEC_COMMANDS;
    return THREE_D_NON_EXEC_COMMANDS.filter(
      (t) =>
        t.token.toLowerCase().includes(q) ||
        t.category.toLowerCase().includes(q) ||
        t.description.toLowerCase().includes(q) ||
        t.autocadFunction.toLowerCase().includes(q) ||
        t.technicalNote.toLowerCase().includes(q)
    );
  }, [q]);

  return (
    <div className="space-y-6" id="extended-command-registry">
      {/* Overview Card */}
      <div className="bg-slate-900 text-white rounded-xl p-5 border border-slate-800 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-1 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-bold uppercase tracking-wider">
                Registry Bridge Architecture
              </span>
              <span className="text-xs text-slate-400 font-mono">Total 531 Target Explanations</span>
            </div>
            <h2 className="text-lg font-bold text-white mt-1">
              Mac2CAM Extended &amp; Engine-Registered Command Registry
            </h2>
            <p className="text-xs text-slate-300 mt-0.5 max-w-3xl leading-relaxed">
              Completing the full 531 registry entries: In addition to the standard 206 AutoCAD drafting commands, 52 Mac2CAM custom tools, and 132 system variables, the sections below account for duplicate alias registrations, shell/clipboard primitives, and recognized 3D sub-commands.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <div className="relative w-full sm:w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search extended commands..."
                className="w-full pl-9 pr-3 py-1.5 rounded-lg border border-slate-700 text-xs bg-slate-800 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>
          </div>
        </div>

        {/* Section Navigation Tabs */}
        <div className="flex flex-wrap gap-2 mt-4 pt-3 border-t border-slate-800">
          <button
            onClick={() => setActiveSection('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
              activeSection === 'all'
                ? 'bg-amber-500 text-slate-950 font-bold'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            All 3 Extended Sections ({filteredDuplicates.length + filteredMeta.length + filteredThreeD.length})
          </button>
          <button
            onClick={() => setActiveSection('duplicates')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 ${
              activeSection === 'duplicates'
                ? 'bg-amber-500 text-slate-950 font-bold'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <CopyCheck className="w-3.5 h-3.5" />
            <span>Duplicate Registered Aliases ({filteredDuplicates.length})</span>
          </button>
          <button
            onClick={() => setActiveSection('meta')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 ${
              activeSection === 'meta'
                ? 'bg-amber-500 text-slate-950 font-bold'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Application &amp; Clipboard Meta ({filteredMeta.length})</span>
          </button>
          <button
            onClick={() => setActiveSection('threed')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 ${
              activeSection === 'threed'
                ? 'bg-amber-500 text-slate-950 font-bold'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <Box className="w-3.5 h-3.5" />
            <span>3D &amp; Mesh (Recognized / Not Executed) ({filteredThreeD.length})</span>
          </button>
        </div>
      </div>

      {/* SECTION 1: DUPLICATE ALIASES REGISTERED AS SEPARATE COMMANDS */}
      {(activeSection === 'all' || activeSection === 'duplicates') && (
        <div className="bg-white rounded-xl shadow-xs border border-slate-200 overflow-hidden" id="section-duplicate-aliases">
          <div
            onClick={() => setIsDupOpen(!isDupOpen)}
            className="p-4 bg-slate-100 hover:bg-slate-200/70 cursor-pointer flex items-center justify-between border-b border-slate-200 transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-600">
                <CopyCheck className="w-4 h-4" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-bold text-slate-900">
                    Duplicate Aliases Registered as Independent Commands
                  </h3>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-300">
                    {filteredDuplicates.length} Entries
                  </span>
                </div>
                <p className="text-xs text-slate-500">
                  In Mac2CAM's Rust architecture, both the full command name (e.g. <code className="font-mono text-slate-700">3DORBIT</code>) and its shorthand aliases (e.g. <code className="font-mono text-slate-700">3O</code>) are submitted as distinct <code className="font-mono text-slate-700">inventory::submit!</code> commands.
                </p>
              </div>
            </div>
            <div className="text-slate-400">
              {isDupOpen ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
            </div>
          </div>

          {isDupOpen && (
            <div className="p-4">
              <div className="overflow-x-auto border border-slate-200 rounded-lg">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                      <th className="py-2.5 px-3 w-28">Alias Token</th>
                      <th className="py-2.5 px-3 w-36">Canonical AutoCAD Command</th>
                      <th className="py-2.5 px-3 w-36">Category</th>
                      <th className="py-2.5 px-3 w-48">Registered Source Module</th>
                      <th className="py-2.5 px-3">Registration Context &amp; Purpose</th>
                      <th className="py-2.5 px-3 text-right w-16">Copy</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredDuplicates.map((d) => (
                      <tr key={d.aliasToken} className="hover:bg-amber-50/40 transition-colors">
                        <td className="py-2.5 px-3 font-mono font-bold text-amber-950">
                          <span className="px-1.5 py-0.5 rounded bg-amber-100/70 border border-amber-200 text-amber-900">
                            {d.aliasToken}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 font-mono font-bold text-slate-800">
                          *{d.targetCommand}
                        </td>
                        <td className="py-2.5 px-3">
                          <span className="inline-block px-2 py-0.5 rounded text-[10px] font-medium bg-slate-100 text-slate-700 border border-slate-200">
                            {d.category}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 font-mono text-[11px] text-slate-500">
                          {d.sourceModule}
                        </td>
                        <td className="py-2.5 px-3 text-slate-600">
                          {d.reasonForSeparateRegistration}
                        </td>
                        <td className="py-2.5 px-3 text-right">
                          <button
                            onClick={(e) => handleCopy(d.aliasToken, `dup-${d.aliasToken}`, e)}
                            className="p-1 rounded hover:bg-slate-200 text-slate-400 hover:text-slate-700"
                            title={`Copy token ${d.aliasToken}`}
                          >
                            {copiedToken === `dup-${d.aliasToken}` ? (
                              <Check className="w-3.5 h-3.5 text-emerald-600" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* SECTION 2: APPLICATION & CLIPBOARD META-COMMANDS */}
      {(activeSection === 'all' || activeSection === 'meta') && (
        <div className="bg-white rounded-xl shadow-xs border border-slate-200 overflow-hidden" id="section-app-meta">
          <div
            onClick={() => setIsMetaOpen(!isMetaOpen)}
            className="p-4 bg-slate-100 hover:bg-slate-200/70 cursor-pointer flex items-center justify-between border-b border-slate-200 transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-600">
                <Layers className="w-4 h-4" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-bold text-slate-900">
                    Application &amp; Clipboard Meta-Commands
                  </h3>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800 border border-blue-300">
                    {filteredMeta.length} Entries
                  </span>
                </div>
                <p className="text-xs text-slate-500">
                  Windowing, OS clipboard pipeline (<code className="font-mono text-slate-700">COPYCLIP</code>, <code className="font-mono text-slate-700">PASTE</code>), batch file operations (<code className="font-mono text-slate-700">SAVEALL</code>, <code className="font-mono text-slate-700">CLOSEALL</code>), and terminal console actions.
                </p>
              </div>
            </div>
            <div className="text-slate-400">
              {isMetaOpen ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
            </div>
          </div>

          {isMetaOpen && (
            <div className="p-4">
              <div className="overflow-x-auto border border-slate-200 rounded-lg">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                      <th className="py-2.5 px-3 w-32">Command Token</th>
                      <th className="py-2.5 px-3 w-40">Action Type</th>
                      <th className="py-2.5 px-3">Description &amp; Workflow</th>
                      <th className="py-2.5 px-3 w-56">Mac2CAM Engine Behavior</th>
                      <th className="py-2.5 px-3 w-48">AutoCAD Equivalent</th>
                      <th className="py-2.5 px-3 text-right w-16">Copy</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredMeta.map((m) => (
                      <tr key={m.token} className="hover:bg-blue-50/30 transition-colors">
                        <td className="py-2.5 px-3 font-mono font-bold text-blue-950">
                          <span className="px-1.5 py-0.5 rounded bg-blue-50 border border-blue-200 text-blue-900">
                            {m.token}
                          </span>
                        </td>
                        <td className="py-2.5 px-3">
                          <span className="inline-block px-2 py-0.5 rounded text-[10px] font-medium bg-slate-100 text-slate-700 border border-slate-200">
                            {m.actionType}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-slate-700 leading-relaxed">
                          {m.description}
                        </td>
                        <td className="py-2.5 px-3 text-slate-600 font-mono text-[11px]">
                          {m.mac2camBehavior}
                        </td>
                        <td className="py-2.5 px-3 text-slate-500 text-[11px]">
                          {m.autocadBehavior}
                        </td>
                        <td className="py-2.5 px-3 text-right">
                          <button
                            onClick={(e) => handleCopy(m.token, `meta-${m.token}`, e)}
                            className="p-1 rounded hover:bg-slate-200 text-slate-400 hover:text-slate-700"
                            title={`Copy token ${m.token}`}
                          >
                            {copiedToken === `meta-${m.token}` ? (
                              <Check className="w-3.5 h-3.5 text-emerald-600" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* SECTION 3: 3D & MESH SUB-COMMANDS (RECOGNIZED BUT NOT EXECUTED IN MAC2CAM) */}
      {(activeSection === 'all' || activeSection === 'threed') && (
        <div className="bg-white rounded-xl shadow-xs border border-rose-200 overflow-hidden" id="section-threed-non-exec">
          <div
            onClick={() => setIsThreeDOpen(!isThreeDOpen)}
            className="p-4 bg-rose-50/60 hover:bg-rose-100/60 cursor-pointer flex items-center justify-between border-b border-rose-200 transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-600">
                <Box className="w-4 h-4" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-bold text-rose-950">
                    3D &amp; Mesh Sub-Commands (Recognized but Not Executed in Mac2CAM)
                  </h3>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-300">
                    {filteredThreeD.length} Commands
                  </span>
                </div>
                <p className="text-xs text-rose-800/80">
                  These tokens are registered in Mac2CAM for DXF grammar and script compatibility, but return stubbed feedback because full 3D B-Rep/CSG solid modeling is not executed in the 2D drafting engine.
                </p>
              </div>
            </div>
            <div className="text-slate-400">
              {isThreeDOpen ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
            </div>
          </div>

          {isThreeDOpen && (
            <div className="p-4 space-y-3">
              {/* Alert Banner */}
              <div className="bg-rose-50 border border-rose-200 rounded-lg p-3 text-xs text-rose-900 flex items-start gap-2.5">
                <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold">Standard AutoCAD Execution: </span>
                  In standard AutoCAD, all 28 of these commands execute complete 3D solid and surface operations (such as dynamic press-pulling, ACIS boolean unions, and polygon meshing). In Mac2CAM, they are recognized in the command dispatcher to prevent syntax crashes, but display a notification that 3D solid operations require the external CAD/CAM 3D module.
                </div>
              </div>

              <div className="overflow-x-auto border border-slate-200 rounded-lg">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                      <th className="py-2.5 px-3 w-32">Command Token</th>
                      <th className="py-2.5 px-3 w-40">Category</th>
                      <th className="py-2.5 px-3 w-44">Mac2CAM Status</th>
                      <th className="py-2.5 px-3">AutoCAD 3D Function</th>
                      <th className="py-2.5 px-3 w-64">Technical Reason for Stubbing</th>
                      <th className="py-2.5 px-3 text-right w-16">Copy</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredThreeD.map((t) => (
                      <tr key={t.token} className="hover:bg-rose-50/30 transition-colors">
                        <td className="py-2.5 px-3 font-mono font-bold text-rose-950">
                          <span className="px-1.5 py-0.5 rounded bg-rose-100/70 border border-rose-200 text-rose-900">
                            {t.token}
                          </span>
                        </td>
                        <td className="py-2.5 px-3">
                          <span className="inline-block px-2 py-0.5 rounded text-[10px] font-medium bg-slate-100 text-slate-700 border border-slate-200">
                            {t.category}
                          </span>
                        </td>
                        <td className="py-2.5 px-3">
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-amber-50 text-amber-800 border border-amber-200">
                            <span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
                            <span>Recognized / Stubbed</span>
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-slate-700 leading-relaxed">
                          <div>{t.autocadFunction}</div>
                          <div className="text-[11px] text-slate-500 mt-0.5">{t.description}</div>
                        </td>
                        <td className="py-2.5 px-3 text-slate-500 font-mono text-[11px]">
                          {t.technicalNote}
                        </td>
                        <td className="py-2.5 px-3 text-right">
                          <button
                            onClick={(e) => handleCopy(t.token, `threed-${t.token}`, e)}
                            className="p-1 rounded hover:bg-slate-200 text-slate-400 hover:text-slate-700"
                            title={`Copy token ${t.token}`}
                          >
                            {copiedToken === `threed-${t.token}` ? (
                              <Check className="w-3.5 h-3.5 text-emerald-600" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
