import React, { useState, useMemo } from 'react';
import { MAC2CAM_CUSTOM_COMMANDS, Mac2CamCustomCommand } from '../data/mac2camCommands';
import { 
  Terminal, 
  Search, 
  Copy, 
  Check, 
  HelpCircle, 
  ExternalLink, 
  ChevronRight, 
  ChevronDown, 
  Filter, 
  AlertTriangle,
  Code2,
  Boxes,
  Layers,
  Sparkles
} from 'lucide-react';

export const Mac2CamCustomSection: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [isExpanded, setIsExpanded] = useState(true);
  const [selectedItem, setSelectedItem] = useState<Mac2CamCustomCommand | null>(null);

  const categories = useMemo(() => {
    return [
      'All',
      'Geometric Sub-Dispatcher',
      'Application / Shell',
      'Editor State / Workflow',
      'Specialized Export',
      'Custom Shorthand',
    ];
  }, []);

  const handleCopy = (text: string, id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(text);
    setCopiedKey(id);
    setTimeout(() => setCopiedKey(null), 1800);
  };

  const filteredCommands = useMemo(() => {
    const q = searchTerm.toLowerCase().trim();
    return MAC2CAM_CUSTOM_COMMANDS.filter((cmd) => {
      if (selectedCategory !== 'All' && cmd.category !== selectedCategory) {
        return false;
      }
      if (q) {
        const matchName = cmd.command.toLowerCase().includes(q);
        const matchExpl = cmd.explanation.toLowerCase().includes(q);
        const matchEquiv = cmd.autocadEquivalent.toLowerCase().includes(q);
        const matchSrc = cmd.sourceFile.toLowerCase().includes(q);
        if (!matchName && !matchExpl && !matchEquiv && !matchSrc) {
          return false;
        }
      }
      return true;
    });
  }, [searchTerm, selectedCategory]);

  const categoryBadge = (cat: Mac2CamCustomCommand['category']) => {
    switch (cat) {
      case 'Geometric Sub-Dispatcher':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'Application / Shell':
        return 'bg-purple-50 text-purple-700 border-purple-200';
      case 'Editor State / Workflow':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'Specialized Export':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'Custom Shorthand':
        return 'bg-rose-50 text-rose-700 border-rose-200';
      default:
        return 'bg-slate-50 text-slate-700 border-slate-200';
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-xs border border-slate-200 overflow-hidden" id="mac2cam-custom-section">
      {/* Header bar */}
      <div 
        onClick={() => setIsExpanded(!isExpanded)}
        className="p-5 bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 text-white cursor-pointer select-none flex flex-col sm:flex-row sm:items-center justify-between gap-3"
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-indigo-500/20 border border-indigo-400/30 flex items-center justify-center text-indigo-400 shadow-inner">
            <Terminal className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-white tracking-tight">
                Mac2CAM Custom &amp; Extended Commands Registry
              </h3>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-500 text-white uppercase tracking-wider">
                {MAC2CAM_CUSTOM_COMMANDS.length} Custom Tokens
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-0.5">
              Commands specific to the Mac2CAM Rust engine that are <strong>not standard out-of-the-box AutoCAD commands</strong>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs font-semibold text-indigo-300">
          <span>{isExpanded ? 'Collapse Section' : 'Expand Section'}</span>
          {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
        </div>
      </div>

      {isExpanded && (
        <div className="p-5 space-y-4">
          {/* Explanation banner */}
          <div className="bg-amber-50/80 border border-amber-200/90 rounded-lg p-3.5 text-xs text-amber-900 leading-relaxed flex items-start gap-2.5">
            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold text-amber-900">Why are these commands listed here? </span>
              In standard AutoCAD, typing these tokens directly into the command bar will result in <code className="px-1 py-0.5 bg-amber-100/80 text-amber-950 rounded font-mono font-bold">Unknown command</code>. In Mac2CAM, they are registered via <code className="px-1 py-0.5 bg-amber-100/80 text-amber-950 rounded font-mono">inventory::submit!</code> to bypass sub-prompts or execute application-specific workflows.
            </div>
          </div>

          {/* Search & Category Filter */}
          <div className="flex flex-col sm:flex-row gap-2.5 items-center justify-between">
            <div className="relative w-full sm:w-80">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Filter custom commands (e.g. ARC_3P, PERF, 3O)..."
                className="w-full pl-9 pr-3 py-1.5 rounded-lg border border-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-slate-50/50 hover:bg-white"
              />
            </div>

            <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1">
              {categories.map((cat) => {
                const count = cat === 'All' 
                  ? MAC2CAM_CUSTOM_COMMANDS.length 
                  : MAC2CAM_CUSTOM_COMMANDS.filter((c) => c.category === cat).length;
                return (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-2.5 py-1 rounded-full text-xs font-medium whitespace-nowrap transition-colors flex items-center gap-1 ${
                      selectedCategory === cat
                        ? 'bg-indigo-600 text-white shadow-2xs'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    <span>{cat}</span>
                    <span className={`text-[10px] px-1 rounded-full ${selectedCategory === cat ? 'bg-indigo-800 text-indigo-100' : 'bg-slate-200 text-slate-600'}`}>
                      {count}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Table of Custom Commands */}
          <div className="border border-slate-200 rounded-lg overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                    <th className="py-2.5 px-3 w-40">Mac2CAM Command</th>
                    <th className="py-2.5 px-3 w-48">Classification</th>
                    <th className="py-2.5 px-3">Purpose &amp; Mac2CAM Behavior</th>
                    <th className="py-2.5 px-3 w-64">Standard AutoCAD Equivalent</th>
                    <th className="py-2.5 px-3 text-right w-20">Copy</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredCommands.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-8 text-center text-slate-400">
                        No custom Mac2CAM commands found matching your search.
                      </td>
                    </tr>
                  ) : (
                    filteredCommands.map((item) => (
                      <tr
                        key={item.command}
                        onClick={() => setSelectedItem(item)}
                        className="hover:bg-indigo-50/40 cursor-pointer transition-colors group"
                      >
                        <td className="py-2.5 px-3 font-mono font-bold text-indigo-900">
                          <div className="flex items-center gap-1.5">
                            <span className="px-1.5 py-0.5 rounded bg-indigo-50 border border-indigo-200 text-indigo-950 font-black text-xs">
                              {item.command}
                            </span>
                          </div>
                        </td>

                        <td className="py-2.5 px-3">
                          <span className={`inline-block px-2 py-0.5 rounded text-[11px] font-medium border ${categoryBadge(item.category)}`}>
                            {item.category}
                          </span>
                        </td>

                        <td className="py-2.5 px-3 text-slate-700">
                          <div>{item.explanation}</div>
                          <div className="text-[10px] text-slate-400 font-mono mt-0.5 flex items-center gap-1">
                            <Code2 className="w-3 h-3 text-slate-400" />
                            <span>{item.sourceFile}</span>
                            {item.stepsCount > 1 && (
                              <span className="text-amber-600 font-sans font-medium">({item.stepsCount} steps)</span>
                            )}
                          </div>
                        </td>

                        <td className="py-2.5 px-3 text-slate-800 font-medium">
                          <div className="bg-slate-100/80 px-2 py-1 rounded text-slate-700 font-mono text-[11px] border border-slate-200">
                            {item.autocadEquivalent}
                          </div>
                        </td>

                        <td className="py-2.5 px-3 text-right">
                          <button
                            onClick={(e) => handleCopy(item.command, item.command, e)}
                            className="p-1 rounded hover:bg-slate-200 text-slate-400 hover:text-slate-700 transition-colors"
                            title="Copy command name"
                          >
                            {copiedKey === item.command ? (
                              <Check className="w-3.5 h-3.5 text-emerald-600" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between text-[11px] text-slate-500 pt-1">
            <span>
              Showing {filteredCommands.length} of {MAC2CAM_CUSTOM_COMMANDS.length} non-standard commands registered in Mac2CAM.
            </span>
            <span>
              Source: Generated from <code className="font-mono text-slate-700">CadCommand</code> registrations in Mac2CAM Rust repository.
            </span>
          </div>
        </div>
      )}

      {/* Detail Modal */}
      {selectedItem && (
        <div
          className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-50 flex items-center justify-center p-4"
          onClick={() => setSelectedItem(null)}
        >
          <div
            className="bg-white rounded-xl shadow-xl border border-slate-200 max-w-md w-full overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="bg-slate-900 text-white p-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded bg-indigo-600 font-mono font-black text-sm">
                  {selectedItem.command}
                </span>
                <span className="text-xs text-slate-300">Mac2CAM Custom Token</span>
              </div>
              <button
                onClick={() => setSelectedItem(null)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs">
              <div>
                <span className="text-slate-400 uppercase font-semibold text-[10px] block mb-1">
                  Category
                </span>
                <span className={`inline-block px-2 py-0.5 rounded font-medium border ${categoryBadge(selectedItem.category)}`}>
                  {selectedItem.category}
                </span>
              </div>

              <div>
                <span className="text-slate-400 uppercase font-semibold text-[10px] block mb-1">
                  Purpose &amp; Mac2CAM Dispatch
                </span>
                <p className="text-slate-800 text-sm leading-relaxed">{selectedItem.explanation}</p>
              </div>

              <div>
                <span className="text-slate-400 uppercase font-semibold text-[10px] block mb-1">
                  Rust Source File
                </span>
                <code className="bg-slate-100 text-slate-800 px-2 py-1 rounded font-mono block border border-slate-200">
                  {selectedItem.sourceFile}
                </code>
              </div>

              <div>
                <span className="text-slate-400 uppercase font-semibold text-[10px] block mb-1">
                  Initial Prompt in Mac2CAM
                </span>
                <div className="bg-slate-900 text-emerald-400 p-2 rounded font-mono text-[11px] border border-slate-800">
                  {selectedItem.initialPrompt}
                </div>
              </div>

              <div>
                <span className="text-slate-400 uppercase font-semibold text-[10px] block mb-1">
                  Standard AutoCAD Behavior &amp; Equivalent
                </span>
                <div className="bg-amber-50 border border-amber-200 rounded p-2.5 text-amber-900">
                  <p className="font-semibold mb-0.5">AutoCAD command line response: <span className="font-normal font-mono text-red-700">Unknown command "{selectedItem.command}"</span></p>
                  <p className="mt-1">Standard AutoCAD method: <strong>{selectedItem.autocadEquivalent}</strong></p>
                </div>
              </div>
            </div>

            <div className="bg-slate-50 border-t border-slate-100 px-5 py-3 flex justify-end">
              <button
                onClick={() => setSelectedItem(null)}
                className="px-3 py-1.5 rounded-md bg-slate-200 hover:bg-slate-300 font-medium text-slate-800 text-xs"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
