import React, { useState } from 'react';
import { AutoCADAlias, CommandCategory } from '../types';
import { KEYBOARD_SHORTCUTS } from '../data/shortcutsData';
import { SysVarsSection } from './SysVarsSection';
import { ExtendedCommandSections } from './ExtendedCommandSections';
import { Mac2CamCustomSection } from './Mac2CamCustomSection';
import { Printer, Check, Info } from 'lucide-react';

interface StructuredDocViewProps {
  aliases: AutoCADAlias[];
}

export const StructuredDocView: React.FC<StructuredDocViewProps> = ({ aliases }) => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(id);
    setTimeout(() => setCopiedKey(null), 1500);
  };

  // Group aliases by category
  const categories: CommandCategory[] = [
    'Draw',
    'Modify',
    'Dimension',
    'Annotation',
    'Layers & Properties',
    'View & Navigation',
    'Blocks & References',
    'Inquiry & Measure',
    '3D Modeling',
    'System & Utilities',
  ];

  const grouped = categories.reduce((acc, cat) => {
    acc[cat] = aliases.filter((a) => a.category === cat);
    return acc;
  }, {} as Record<CommandCategory, AutoCADAlias[]>);

  // Single key shortcuts summary
  const singleKeyList = aliases
    .filter((a) => a.isSingleKey && a.hasDefaultAlias)
    .sort((a, b) => a.alias.localeCompare(b.alias));

  return (
    <div className="space-y-6 print:space-y-4 print:text-black">
      {/* Top Banner & Print Notice */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs print:border-none print:shadow-none print:p-0">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-5 mb-5 print:mb-3">
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-red-100 text-red-800 mb-2">
              <span>AutoCAD &amp; Mac2CAM Master Reference</span>
            </div>
            <h2 className="text-2xl font-bold text-slate-900 tracking-tight">
              AutoCAD &amp; Mac2CAM Commands
            </h2>
            <p className="text-sm text-slate-500 mt-1 max-w-3xl">
              Complete desk reference covering 531 command tokens across 6 distinct sections: Core AutoCAD 2D Drafting Commands &amp; Aliases (206), Custom Mac2CAM CNC/Manufacturing Tools (52), AutoCAD System Variables (132), Duplicate Registered Command Aliases (74), Application &amp; Clipboard Meta-Commands (39), and Recognized 3D/Mesh Sub-Commands (28).
            </p>
          </div>

          <div className="flex items-center gap-2 print:hidden">
            <button
              onClick={() => window.print()}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold shadow-xs transition-colors"
            >
              <Printer className="w-4 h-4" />
              <span>Print Cheat Sheet / PDF</span>
            </button>
          </div>
        </div>

        {/* Legend */}
        <div className="mb-6 p-3 bg-slate-50 border border-slate-200 rounded-lg flex flex-wrap items-center gap-4 text-xs text-slate-600 print:bg-transparent print:p-1">
          <span className="font-semibold text-slate-800">Legend:</span>
          <div className="flex items-center gap-1.5">
            <span className="px-1.5 py-0.5 rounded bg-amber-500 text-white font-mono font-bold text-[10px]">L</span>
            <span>1-Key Priority Shortcut</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="px-1.5 py-0.5 rounded bg-slate-900 text-white font-mono font-bold text-[10px]">PL</span>
            <span>Standard acad.pgp Alias</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="px-1.5 py-0.5 rounded bg-slate-100 border border-dashed border-slate-400 text-slate-600 font-mono text-[10px]">None</span>
            <span>Full Command (No Default Shortcut)</span>
          </div>
        </div>

        {/* Section 1: The Essential One-Key Quick Keys */}
        <div className="mb-8 print:mb-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <span className="w-6 h-6 rounded-md bg-amber-100 text-amber-900 flex items-center justify-center text-xs font-black">
                1K
              </span>
              <span>The 1-Key Priority Aliases (A-Z Direct Keys)</span>
            </h3>
            <span className="text-xs text-slate-500">{singleKeyList.length} Single-Key Commands</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2">
            {singleKeyList.map((item) => (
              <div
                key={item.id}
                onClick={() => handleCopy(item.alias, `1k-${item.id}`)}
                className="group relative flex items-center justify-between p-2 rounded-lg border border-amber-200 bg-amber-50/40 hover:bg-amber-100/60 hover:border-amber-300 transition-colors cursor-pointer"
                title={`${item.command}: ${item.description}`}
              >
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded bg-amber-500 text-white font-mono font-black text-xs flex items-center justify-center shadow-2xs">
                    {item.alias}
                  </span>
                  <span className="font-mono text-xs font-bold text-slate-800">{item.command}</span>
                </div>
                {copiedKey === `1k-${item.id}` ? (
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                ) : (
                  <span className="text-[10px] text-amber-700 opacity-0 group-hover:opacity-100 transition-opacity">
                    Copy
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Section 2: Function Keys (F1-F12) */}
        <div className="mb-8 print:mb-4">
          <h3 className="text-base font-bold text-slate-900 flex items-center gap-2 mb-3">
            <span className="w-6 h-6 rounded-md bg-blue-100 text-blue-900 flex items-center justify-center text-xs font-black">
              Fn
            </span>
            <span>Drafting Toggles &amp; Function Keys (F1 – F12)</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2.5">
            {KEYBOARD_SHORTCUTS.filter((s) => s.category === 'Function Keys').map((shortcut) => (
              <div
                key={shortcut.key}
                className="p-2.5 rounded-lg border border-slate-200 bg-slate-50/50 flex flex-col justify-between"
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="px-2 py-0.5 rounded bg-slate-900 text-white font-mono font-bold text-xs">
                    {shortcut.key}
                  </span>
                  <span className="font-semibold text-xs text-slate-800">{shortcut.name}</span>
                </div>
                <p className="text-[11px] text-slate-500 leading-tight">{shortcut.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Section 3: Essential Control Accelerators */}
        <div className="mb-8 print:mb-4">
          <h3 className="text-base font-bold text-slate-900 flex items-center gap-2 mb-3">
            <span className="w-6 h-6 rounded-md bg-slate-800 text-white flex items-center justify-center text-xs font-black">
              ^
            </span>
            <span>Control Accelerators &amp; System Toggles</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2.5">
            {KEYBOARD_SHORTCUTS.filter((s) => s.category === 'Control Shortcuts').map((shortcut) => (
              <div
                key={shortcut.key}
                className="p-2.5 rounded-lg border border-slate-200 bg-slate-50/50 flex flex-col justify-between"
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-100 font-mono font-medium text-[11px]">
                    {shortcut.key}
                  </span>
                  <span className="font-semibold text-xs text-slate-800">{shortcut.name}</span>
                </div>
                <p className="text-[11px] text-slate-500 leading-tight">{shortcut.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Section 4: Categorized Command Aliases Structured Tables */}
        <div className="space-y-8 print:space-y-6">
          <div className="border-t border-slate-200 pt-6">
            <h3 className="text-lg font-bold text-slate-900 mb-1">
              Complete Categorized AutoCAD Commands Reference
            </h3>
            <p className="text-xs text-slate-500 mb-6">
              Organized by drafting discipline. Shows keyboard shortcuts, full AutoCAD command names, acad.pgp syntax, and practical tips.
            </p>
          </div>

          {categories.map((cat) => {
            const list = grouped[cat] || [];
            if (list.length === 0) return null;

            return (
              <div key={cat} className="space-y-3 break-inside-avoid">
                <div className="flex items-center justify-between border-b border-slate-200 pb-1.5">
                  <h4 className="text-sm font-bold uppercase tracking-wider text-slate-800 flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-red-600"></span>
                    <span>{cat} Commands</span>
                  </h4>
                  <span className="text-xs text-slate-400 font-mono">{list.length} commands</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5">
                  {list.map((item) => (
                    <div
                      key={item.id}
                      onClick={() => {
                        const textToCopy = item.hasDefaultAlias
                          ? item.syntax
                          : `${item.suggestedAlias || 'CUSTOM'}, *${item.command}`;
                        handleCopy(textToCopy, `doc-${item.id}`);
                      }}
                      className="p-2.5 rounded-lg border border-slate-200 bg-white hover:border-slate-300 hover:shadow-2xs transition-all cursor-pointer group"
                    >
                      <div className="flex items-center justify-between mb-1">
                        <div className="flex items-center gap-2">
                          {item.hasDefaultAlias ? (
                            <span
                              className={`px-2 py-0.5 rounded text-xs font-mono font-black ${
                                item.isSingleKey
                                  ? 'bg-amber-100 text-amber-900 border border-amber-300'
                                  : 'bg-slate-100 text-slate-900 border border-slate-200'
                              }`}
                            >
                              {item.alias}
                            </span>
                          ) : (
                            <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-slate-100 text-slate-500 border border-dashed border-slate-300">
                              {item.suggestedAlias ? `Rec: ${item.suggestedAlias}` : 'Full Cmd'}
                            </span>
                          )}
                          <span className="font-mono text-xs font-bold text-slate-900">
                            {item.command}
                          </span>
                        </div>
                        {copiedKey === `doc-${item.id}` ? (
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                        ) : (
                          <span className="text-[10px] font-mono text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity">
                            copy pgp
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                        {item.description}
                      </p>
                      {item.tips && (
                        <p className="text-[11px] text-slate-400 mt-1 line-clamp-1 italic">
                          {item.tips}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* AutoCAD System Variables Section */}
      <div className="print:break-before-page">
        <SysVarsSection />
      </div>

      {/* Mac2CAM Extended Registry (Duplicates, Meta Primitives, 3D/Mesh) */}
      <div className="print:break-before-page">
        <ExtendedCommandSections />
      </div>

      {/* Mac2CAM Custom Commands Reference */}
      <div className="print:break-before-page">
        <Mac2CamCustomSection />
      </div>
    </div>
  );
};
