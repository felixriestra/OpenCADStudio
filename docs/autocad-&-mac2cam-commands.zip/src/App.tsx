import React, { useState } from 'react';
import { ViewMode, AutoCADAlias } from './types';
import { AUTOCAD_ALIASES } from './data/aliasesData';
import { Header } from './components/Header';
import { AliasTable } from './components/AliasTable';
import { SysVarsSection } from './components/SysVarsSection';
import { ExtendedCommandSections } from './components/ExtendedCommandSections';
import { StructuredDocView } from './components/StructuredDocView';
import { HowToGuide } from './components/HowToGuide';
import { PgpCustomizer } from './components/PgpCustomizer';
import { CommandSimulator } from './components/CommandSimulator';

export default function App() {
  const [currentView, setCurrentView] = useState<ViewMode>('table');
  const [aliases, setAliases] = useState<AutoCADAlias[]>(AUTOCAD_ALIASES);

  // Export as CSV
  const handleExportCSV = () => {
    const headers = ['Alias / Shortcut', 'AutoCAD Command', 'Category', 'Has Stock Alias', 'acad.pgp Syntax', 'Description', 'Drafting Tips', 'Frequency'];
    const rows = aliases.map((a) => [
      `"${a.hasDefaultAlias ? a.alias : (a.suggestedAlias ? `[Suggested: ${a.suggestedAlias}]` : 'None')}"`,
      `"${a.command}"`,
      `"${a.category}"`,
      `"${a.hasDefaultAlias ? 'Yes' : 'No'}"`,
      `"${a.hasDefaultAlias ? a.syntax : `${a.suggestedAlias || 'CUSTOM'}, *${a.command}`}"`,
      `"${a.description.replace(/"/g, '""')}"`,
      `"${(a.tips || '').replace(/"/g, '""')}"`,
      `"${a.frequency}"`,
    ]);

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'autocad_command_reference_table.csv';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Export as Markdown Table
  const handleExportMarkdown = () => {
    let md = '# AutoCAD Master Command & Shortcuts Reference Document\n\n';
    md += '> Complete reference of AutoCAD commands, standard acad.pgp aliases, and custom shortcuts.\n\n';
    md += '| Shortcut / Alias | AutoCAD Command | Category | acad.pgp Syntax | Description |\n';
    md += '| :--- | :--- | :--- | :--- | :--- |\n';

    aliases.forEach((a) => {
      const aliasCol = a.hasDefaultAlias
        ? `**${a.alias}**`
        : `*(None - Rec: ${a.suggestedAlias || '—'})*`;
      const syntaxCol = a.hasDefaultAlias
        ? `\`${a.syntax}\``
        : `\`${a.suggestedAlias || 'CUSTOM'}, *${a.command}\``;
      md += `| ${aliasCol} | \`${a.command}\` | ${a.category} | ${syntaxCol} | ${a.description} |\n`;
    });

    const blob = new Blob([md], { type: 'text/markdown;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'autocad_commands_reference.md';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handlePrint = () => {
    // Switch to document view if on another tab for best print layout
    if (currentView !== 'document') {
      setCurrentView('document');
      setTimeout(() => {
        window.print();
      }, 250);
    } else {
      window.print();
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-900 selection:bg-red-100 selection:text-red-900">
      {/* Header */}
      <Header
        currentView={currentView}
        onViewChange={setCurrentView}
        onPrint={handlePrint}
        onExportCSV={handleExportCSV}
        onExportMarkdown={handleExportMarkdown}
        totalAliasesCount={aliases.length}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 pb-24">
        {currentView === 'table' && <AliasTable aliases={aliases} />}
        {currentView === 'sysvars' && <SysVarsSection isStandAlonePage={true} />}
        {currentView === 'extended' && <ExtendedCommandSections />}
        {currentView === 'document' && <StructuredDocView aliases={aliases} />}
        {currentView === 'guide' && <HowToGuide />}
        {currentView === 'customizer' && <PgpCustomizer defaultAliases={aliases} />}
      </main>

      {/* AutoCAD Command Line Simulator Dock */}
      <CommandSimulator aliases={aliases} />

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-4 text-center text-xs text-slate-500 print:hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div>
            AutoCAD &amp; Mac2CAM Commands Reference • Based on{' '}
            <a
              href="https://www.autodesk.com/blogs/autocad/autocad-command-aliases/"
              target="_blank"
              rel="noopener noreferrer"
              className="text-red-600 hover:underline font-medium"
            >
              Autodesk AutoCAD Guidelines
            </a>
            {' '}&amp; Mac2CAM Rust Command Registry
          </div>
          <div className="flex items-center gap-4 text-slate-400">
            <span>Standard Syntax: <code className="text-slate-600 font-mono">ALIAS, *COMMAND</code></span>
            <span>•</span>
            <span>Reload: <code className="text-slate-600 font-mono">REINIT</code></span>
          </div>
        </div>
      </footer>
    </div>
  );
}
